package net.sf.jgamelibrary.physics.test.xpilot;

import java.awt.Color;
import java.awt.Graphics2D;

import net.sf.jgamelibrary.geom.Polygon2D;

public class Bullet extends XPilotEntity {

	public static final double BULLET_RADIUS = 5.0;
	private static final Polygon2D BULLET_POLYGON2D = Polygon2D.regularPolygon(6, BULLET_RADIUS, 0);
	public static final double BULLET_MASS = 0.5;
	
	boolean active=false;
	
	public Bullet() {
		super(BULLET_POLYGON2D, BULLET_MASS);
	}
	
	@Override
	public boolean interactsWith(XPilotEntity other) {return !other.isBullet();}

	@Override
	public boolean isActive() {return active;}
	
	@Override
	public boolean isBullet() {return true;}
	
	@Override
	public void render(Graphics2D g2d) {
		g2d.setColor(Color.WHITE);
		super.getBounds().render(g2d);
	}
}
