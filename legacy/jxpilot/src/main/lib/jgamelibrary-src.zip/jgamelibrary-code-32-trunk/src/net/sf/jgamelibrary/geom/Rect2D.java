package net.sf.jgamelibrary.geom;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.List;
import java.util.ArrayList;

public class Rect2D extends Rectangle2D implements AbstractPolygon2D {

	/**
	 * The bottom left corner.
	 */
	private Vector2D corner,
	/**
	 * The dimensions.
	 */
	size;
	/**
	 * The vertices of the rectangle. They are contained in counterclockwise
	 * order, starting from the lower left.
	 */
	private List<Vector2D> vertices;
	private List<Edge2D> edges;
	
	public Rect2D() {
		corner = new Vector2D();
		size = new Vector2D();
		vertices = new ArrayList<Vector2D>(4);
		initEdges();
	}
	
	private void initEdges() {
		edges = new ArrayList<Edge2D>();
		for(int i = 0;i<4;i++) {
			edges.add(new Edge2D(vertices.get(i), vertices.get((i+1)%4)));
		}
	}
	
	public Rect2D(double x, double y, double w, double h) {
		this();
		setRect(x,y,w,h);
	}
	
	@Override
	public Rect2D createIntersection(Rectangle2D arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Rect2D createUnion(Rectangle2D arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int outcode(double x, double y) {
		int result = 0;
		if(x<corner.getX()) result |= Rectangle2D.OUT_LEFT;
		else if(corner.getX()+size.getX()<x) result |= Rectangle2D.OUT_RIGHT;
		if(y<corner.getY()) result |= Rectangle2D.OUT_BOTTOM;
		else if(corner.getY()+size.getY()<y) result |= Rectangle2D.OUT_TOP;
		return result;
	}

	private void setVertices() {
		vertices.get(0).setLocation(corner);
		vertices.get(1).setCartesian(corner.getX()+size.getX(), corner.getY());
		vertices.get(2).setFrom(corner).add(size);
		vertices.get(3).setCartesian(corner.getX(), corner.getY()+size.getY());		
	}
	
	@Override
	public void setRect(double x, double y, double w, double h) {
		corner.setLocation(x, y);
		size.setCartesian(w,h);
		setVertices();
	}

	@Override
	public double getHeight() {
		return size.getY();
	}

	@Override
	public double getWidth() {
		return size.getX();
	}

	@Override
	public double getX() {
		return corner.getX();
	}

	@Override
	public double getY() {
		return corner.getY();
	}

	@Override
	public Vector2D getVertex(int index) {return vertices.get(index);}
	@Override
	public Line2D getEdge(int index) {return edges.get(index);}
	
	public Rect2D translate(double dx, double dy) {
		corner.add(dx, dy);
		setVertices();
		return this;
	}
	
	public Rect2D translate(Vector2D amount) {
		corner.add(amount);
		setVertices();
		return this;
	}
	
	@Override
	public boolean isEmpty() {
		return size.getX()==0.0 && size.getY()==0.0;
	}

	public double area() {
		return size.getX()*size.getY();
	}
	
	public double perimeter() {
		return 2.0*semiPerimeter();
	}
	
	public double semiPerimeter() {
		return size.getX()+size.getY();
	}

	@Override
	public int numVertices() {
		return 4;
	}

	@Override
	public void render(Graphics2D g) {
		//for(int i = 0;i<4;i++) {
		//	edges.get(i).render(g);
		//}
		g.drawRect((int)(Math.round(corner.getX())), (int)(Math.round(-corner.getY())),
				(int)(Math.round(size.getX())), (int)(Math.round(-size.getY())));
	}
}
