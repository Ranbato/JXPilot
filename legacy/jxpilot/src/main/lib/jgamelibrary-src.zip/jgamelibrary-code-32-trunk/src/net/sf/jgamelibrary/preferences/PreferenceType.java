package net.sf.jgamelibrary.preferences;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * Defines types of preferences.
 * 
 * @author Taras Kostiak
 * 
 */
@XmlType
@XmlEnum
public enum PreferenceType {

    /**
     * Type, that represents a field for text input(<code>JTextField</code> in
     * Swing).
     */
    @XmlEnumValue(value = PreferenceType.TYPE_NAME_TEXT_FIELD)
    TEXT_FIELD,

    /**
     * Type, that represents a check box(<code>JCheckBox</code> in Swing).
     */
    @XmlEnumValue(value = PreferenceType.TYPE_NAME_BOOLEAN)
    BOOLEAN,

    /**
     * Type, that represents a combo box(<code>JComboBox</code> in Swing).
     */
    @XmlEnumValue(value = PreferenceType.TYPE_NAME_COMBO_BOX)
    COMBO_BOX,

    /**
     * Type, that represents path to file(or directory), that can be selectable
     * with JFileChooser in Swing.
     */
    @XmlEnumValue(value = PreferenceType.TYPE_NAME_FILE_PATH)
    FILE_PATH;

    /**
     * Returns text name of preference type.
     * 
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        String typeText = null;
        switch (this) {
            case TEXT_FIELD:
                typeText = TYPE_NAME_TEXT_FIELD;
                break;
            case BOOLEAN:
                typeText = TYPE_NAME_BOOLEAN;
                break;
            case COMBO_BOX:
                typeText = TYPE_NAME_COMBO_BOX;
                break;
            case FILE_PATH:
                typeText = TYPE_NAME_TEXT_FIELD;
                break;

            default:
                break;
        }

        return typeText;
    }

    /**
     * @see #TEXT_FIELD
     */
    public static final String TYPE_NAME_TEXT_FIELD = "textField";

    /**
     * @see #BOOLEAN
     */
    public static final String TYPE_NAME_BOOLEAN = "boolean";

    /**
     * @see #COMBO_BOX
     */
    public static final String TYPE_NAME_COMBO_BOX = "comboBox";

    /**
     * @see #FILE_PATH
     */
    public static final String TYPE_NAME_FILE_PATH = "filePath";

}
