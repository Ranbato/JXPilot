package net.sf.jgamelibrary.options.option;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "decimal")
public class DecimalOption extends Option {

	@XmlElement(name = "value")
	@XmlJavaTypeAdapter(DecimalOption.DoubleAdapter.class)
	private Double value;
		
	DecimalOption() {}
	
	public DecimalOption(String name, double value) {
		super(name);
		setValue(value);
	}

	public Double getValue() {return value;}

	public void setValue(double value) {this.value = value;}

	private static class DoubleAdapter extends XmlAdapter<String, Double> {
		@Override
		public String marshal(Double d) {return String.valueOf(d);}
		@Override
		public Double unmarshal(String s) throws NumberFormatException {return Double.parseDouble(s);}
	}
}
