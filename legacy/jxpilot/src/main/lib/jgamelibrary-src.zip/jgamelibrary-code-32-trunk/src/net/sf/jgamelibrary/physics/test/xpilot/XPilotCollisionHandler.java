package net.sf.jgamelibrary.physics.test.xpilot;

import net.sf.jgamelibrary.physics.Collision;
import net.sf.jgamelibrary.physics.MovingCollisionHandler;

public class XPilotCollisionHandler extends MovingCollisionHandler<XPilotEntity> {

	public XPilotCollisionHandler() {
		super();
	}

	public XPilotCollisionHandler(double normal_friction, double tangent_friction) {
		super(normal_friction, tangent_friction);
	}

	public XPilotCollisionHandler(double friction) {
		super(friction);
	}

	@Override
	public void handleCollision(Collision<? extends XPilotEntity> collision) {
		XPilotEntity e1 = collision.getIncident();
		XPilotEntity e2 = collision.getTarget();
		if(e1.isBullet() && e2 instanceof Wall) {
			((Bullet)e1).active = false;
		} else if(e2.isBullet() && e1 instanceof Wall) {
			((Bullet)e2).active = false;
		} else super.handleCollision(collision);
	}
	
}
