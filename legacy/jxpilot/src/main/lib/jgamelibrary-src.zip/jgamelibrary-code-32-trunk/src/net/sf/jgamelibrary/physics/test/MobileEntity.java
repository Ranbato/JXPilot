package net.sf.jgamelibrary.physics.test;

import net.sf.jgamelibrary.geom.*;

public class MobileEntity extends DefaultEntity{
	public boolean isMobile(){return true;}
	
	public MobileEntity(Polygon2D poly)
	{
		super(poly);
	}
}
