package net.sf.jgamelibrary.physics;

public class WrappingEngine<T extends RotatingEntity2D<T>> {
	
}
