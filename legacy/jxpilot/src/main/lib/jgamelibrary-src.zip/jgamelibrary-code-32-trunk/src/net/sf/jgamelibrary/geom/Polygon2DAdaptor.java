package net.sf.jgamelibrary.geom;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import sun.awt.geom.Crossings;

/**
 * Implements {@code Shape} and {@code Renderable} methods on top of
 * {@code AbstractPolygon2D} methods.
 * @author Vlad Firoiu
 */
public abstract class Polygon2DAdaptor implements AbstractPolygon2D {

	/**
	 * Bounds of the polygon.
	 * This value can be NULL.
	 * Please see the javadoc comments getBounds().
	 *
	 * @serial
	 * @see #getBoundingBox()
	 * @see #getBounds()
	 */
	protected Rectangle2D bounds;
	
	public Polygon2DAdaptor() {
		bounds = new Rectangle2D.Double();
	}
	
	/**
	 * Updates the bounding box.
	 */
	protected void updateBounds() {
		double boundsMinX = Double.MAX_VALUE;
		double boundsMinY = Double.MAX_VALUE;
		double boundsMaxX = Double.MIN_VALUE;
		double boundsMaxY = Double.MIN_VALUE;

		for (int i = 0; i < this.numVertices(); i++) {
			Point2D p = this.getVertex(i);
			double x = p.getX();
			boundsMinX = Math.min(boundsMinX, x);
			boundsMaxX = Math.max(boundsMaxX, x);
			double y = p.getY();
			boundsMinY = Math.min(boundsMinY, y);
			boundsMaxY = Math.max(boundsMaxY, y);
		}
		bounds.setFrameFromDiagonal(boundsMinX, boundsMinY, boundsMaxX, boundsMaxY);
	}
	
	/**
	 * Resizes the bounding box to accomodate the specified coordinates.
	 * @param x,&nbsp;y the specified coordinates
	 */
	protected void updateBounds(double x, double y) {
		bounds.add(x, y);
	}
	
	protected void updateBounds(Point2D p) {
		bounds.add(p);
	}
	
	@Override
	public boolean contains(Point2D p) {
		return contains(p.getX(), p.getY());
	}

	/**
	 * Tests if the interior of this <code>Polygon</code> entirely
	 * contains the specified <code>Rectangle2D</code>.
	 * @param r the specified <code>Rectangle2D</code>
	 * @return <code>true</code> if this <code>Polygon</code> entirely
	 * contains the specified <code>Rectangle2D</code>;
	 * <code>false</code> otherwise.
	 * @see #contains(double, double, double, double)
	 */
	@Override
	public boolean contains(Rectangle2D r) {
		return contains(r.getX(), r.getY(), r.getWidth(), r.getHeight());
	}
	
	/**
	 * Determines if the specified coordinates are inside this
	 * <code>Polygon</code>. For the definition of
	 * <i>insideness</i>, see the class comments of {@link Shape}.
	 * @param x the specified x coordinate
	 * @param y the specified y coordinate
	 * @return <code>true</code> if the <code>Polygon</code> contains the
	 * specified coordinates; <code>false</code> otherwise.
	 */
	@Override
	public boolean contains(double x, double y) {
		if (this.numVertices() <= 2 || !getBounds2D().contains(x, y)) {
			return false;
		}
		int hits = 0;

		Point2D lastPoint = this.getVertex(this.numVertices()-1);
		Point2D curPoint;

		// Walk the edges of the polygon
		for (int i = 0; i < this.numVertices(); lastPoint=curPoint, i++) {

			curPoint = this.getVertex(i);

			if(curPoint.getY()==lastPoint.getY()) {
				continue;
			}

			double leftx;
			if (curPoint.getX() < lastPoint.getX()) {
				if (x >= lastPoint.getX()) {
					continue;
				}
				leftx = curPoint.getX();
			} else {
				if (x >= curPoint.getX()) {
					continue;
				}
				leftx = lastPoint.getX();
			}

			double test1, test2;
			if (curPoint.getY() < lastPoint.getY()) {
				if (y < curPoint.getY() || y >= lastPoint.getY()) {
					continue;
				}
				if (x < leftx) {
					hits++;
					continue;
				}
				test1 = x - curPoint.getX();
				test2 = y - curPoint.getY();
			} else {
				if (y < lastPoint.getY() || y >= curPoint.getY()) {
					continue;
				}
				if (x < leftx) {
					hits++;
					continue;
				}
				test1 = x - lastPoint.getX();
				test2 = y - lastPoint.getY();
			}

			if (test1 < (test2 / (lastPoint.getY() - curPoint.getY()) *
					(lastPoint.getX() - curPoint.getX()))) {
				hits++;
			}
		}

		return ((hits & 1) != 0);
	}

	private Crossings getCrossings(double xlo, double ylo, double xhi, double yhi) {
		Crossings cross = new Crossings.EvenOdd(xlo, ylo, xhi, yhi);

		Point2D lastPoint = this.getVertex(this.numVertices()-1);
		Point2D curPoint;

		// Walk the edges of the polygon
		for (int i = 0; i < this.numVertices(); lastPoint = curPoint, i++) {
			curPoint = this.getVertex(i);
			if (cross.accumulateLine(lastPoint.getX(), lastPoint.getY(), curPoint.getX(), curPoint.getY())) {
				return null;
			}
		}

		return cross;
	}

	/**
	 * Tests if the interior of this <code>Polygon</code> entirely
	 * contains the specified set of rectangular coordinates.
	 * @param x the x coordinate of the top-left corner of the
	 * specified set of rectangular coordinates
	 * @param y the y coordinate of the top-left corner of the
	 * specified set of rectangular coordinates
	 * @param w the width of the set of rectangular coordinates
	 * @param h the height of the set of rectangular coordinates
	 * @return <code>true</code> if this <code>Polygon</code> entirely
	 * contains the specified set of rectangular
	 * coordinates; <code>false</code> otherwise
	 * @since 1.2
	 */	
	@Override
	public boolean contains(double x, double y, double w, double h) {
		if (this.numVertices() <= 0 || !getBounds2D().intersects(x, y, w, h)) {
			return false;
		}

		Crossings cross = getCrossings(x, y, x+w, y+h);
		return (cross != null && cross.covers(y, y+h));
	}

	@Override
	public Rectangle getBounds() {
		return bounds.getBounds();
	}

	@Override
	public Rectangle2D getBounds2D() {
		return bounds;
	}
	
	private final PolygonPathIterator pathIterator = new PolygonPathIterator();
	
	/**
	 * Returns an iterator object that iterates along the boundary of this
	 * <code>Polygon</code> and provides access to the geometry
	 * of the outline of this <code>Polygon</code>. An optional
	 * {@link AffineTransform} can be specified so that the coordinates
	 * returned in the iteration are transformed accordingly.
	 * @param at an optional <code>AffineTransform</code> to be applied to the
	 * coordinates as they are returned in the iteration, or
	 * <code>null</code> if untransformed coordinates are desired
	 * @return a {@link PathIterator} object that provides access to the
	 * geometry of this <code>Polygon</code>.
	 */
	@Override
	public PathIterator getPathIterator(AffineTransform at) {
		return pathIterator.reset(at);
	}

	/**
	 * Returns an iterator object that iterates along the boundary of
	 * the <code>Shape</code> and provides access to the geometry of the
	 * outline of the <code>Shape</code>. Only SEG_MOVETO, SEG_LINETO, and
	 * SEG_CLOSE point types are returned by the iterator.
	 * Since polygons are already flat, the <code>flatness</code> parameter
	 * is ignored. An optional <code>AffineTransform</code> can be specified
	 * in which case the coordinates returned in the iteration are transformed
	 * accordingly.
	 * @param at an optional <code>AffineTransform</code> to be applied to the
	 * coordinates as they are returned in the iteration, or
	 * <code>null</code> if untransformed coordinates are desired
	 * @param flatness the maximum amount that the control points
	 * for a given curve can vary from colinear before a subdivided
	 * curve is replaced by a straight line connecting the
	 * endpoints. Since polygons are already flat the
	 * <code>flatness</code> parameter is ignored.
	 * @return a <code>PathIterator</code> object that provides access to the
	 * <code>Shape</code> object's geometry.
	 */
	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return getPathIterator(at);
	}

	private class PolygonPathIterator extends AbstractPolygonPathIterator {
		AffineTransform at;
		
		public PathIterator reset(AffineTransform at) {
			this.at = at;
			return super.reset();
		}
		
		@Override
		AbstractPolygon2D getPolygon() {return Polygon2DAdaptor.this;}

		@Override
		AffineTransform getTransform() {return at;}
	}
	
	/**
	 * Tests if the interior of this <code>Polygon</code> intersects the
	 * interior of a specified <code>Rectangle2D</code>.
	 * @param r a specified <code>Rectangle2D</code>
	 * @return <code>true</code> if this <code>Polygon</code> and the
	 * interior of the specified <code>Rectangle2D</code>
	 * intersect each other; <code>false</code>
	 * otherwise.
	 */
	@Override
	public boolean intersects(Rectangle2D r) {
		return intersects(r.getX(), r.getY(), r.getWidth(), r.getHeight());
	}

	/**
	 * Tests if the interior of this <code>Polygon</code> intersects the
	 * interior of a specified set of rectangular coordinates.
	 * @param x the x coordinate of the specified rectangular
	 * shape's top-left corner
	 * @param y the y coordinate of the specified rectangular
	 * shape's top-left corner
	 * @param w the width of the specified rectangular shape
	 * @param h the height of the specified rectangular shape
	 * @return <code>true</code> if the interior of this
	 * <code>Polygon</code> and the interior of the
	 * specified set of rectangular
	 * coordinates intersect each other;
	 * <code>false</code> otherwise
	 * @since 1.2
	 */
	@Override
	public boolean intersects(double x, double y, double w, double h) {
		if (this.numVertices() <= 0 || !getBounds2D().intersects(x, y, w, h)) {
			return false;
		}

		Crossings cross = getCrossings(x, y, x+w, y+h);
		return (cross == null || !cross.isEmpty());
	}
	
	@Override
	public void render(Graphics2D g2d) {draw(g2d);}
	
	public void draw(Graphics g) {
		for(int i = 0;i<this.numVertices();i++) {
			this.getEdge(i).draw(g);
		}
	}
	
	public void draw(Graphics g, double x, double y) {
		for(int i = 0;i<this.numVertices();i++) {
			this.getEdge(i).draw(g, x, y);
		}
	}
	
	public void draw(Graphics g, int x, int y) {
		for(int i = 0;i<this.numVertices();i++) {
			this.getEdge(i).draw(g, x, y);
		}
	}
	
	private final InvertedPolygon2D invertedPolygon = new InvertedPolygon2D();
	
	public void fill(Graphics2D g2d) {
		g2d.fill(invertedPolygon);
	}
	
	private class InvertedPolygon2D implements AbstractPolygon2D {

		@Override
		public boolean contains(Point2D p) {
			return Polygon2DAdaptor.this.contains(p);
		}

		@Override
		public boolean contains(Rectangle2D r) {
			return Polygon2DAdaptor.this.contains(r);
		}

		@Override
		public boolean contains(double x, double y) {
			return Polygon2DAdaptor.this.contains(x, y);
		}

		@Override
		public boolean contains(double x, double y, double w, double h) {
			return Polygon2DAdaptor.this.contains(x, y, w, h);
		}

		@Override
		public Rectangle getBounds() {
			return Polygon2DAdaptor.this.getBounds();
		}

		@Override
		public Rectangle2D getBounds2D() {
			return Polygon2DAdaptor.this.getBounds2D();
		}
		
		private final InvertedPathIterator invertedIterator = new InvertedPathIterator();
		
		@Override
		public PathIterator getPathIterator(AffineTransform at) {
			return invertedIterator.reset(at);
		}

		@Override
		public PathIterator getPathIterator(AffineTransform at, double flatness) {
			return getPathIterator(at);
		}
		
		private class InvertedPathIterator extends AbstractPolygonPathIterator {
			AffineTransform at;
			
			public PathIterator reset(AffineTransform at) {
				this.at = at;
				return super.reset();
			}

			@Override
			AbstractPolygon2D getPolygon() {return InvertedPolygon2D.this;}

			@Override
			AffineTransform getTransform() {return at;}
			
			@Override
			public int currentSegment(double[] coords) {
				int temp = super.currentSegment(coords);
				coords[1] = -coords[1];
				return temp;
			}

			@Override
			public int currentSegment(float[] coords) {
				int temp = super.currentSegment(coords);
				coords[1] = -coords[1];
				return temp;
			}
		}
		
		@Override
		public boolean intersects(Rectangle2D r) {
			return Polygon2DAdaptor.this.intersects(r);
		}

		@Override
		public boolean intersects(double x, double y, double w, double h) {
			return Polygon2DAdaptor.this.intersects(x, y, w, h);
		}

		@Override
		public Line2D getEdge(int index) {
			return Polygon2DAdaptor.this.getEdge(index);
		}

		@Override
		public Vector2D getVertex(int index) {
			return Polygon2DAdaptor.this.getVertex(index);
		}

		@Override
		public int numVertices() {
			return Polygon2DAdaptor.this.numVertices();
		}

		@Override
		public void render(Graphics2D g) {
			Polygon2DAdaptor.this.render(g);
		}
	}
}
