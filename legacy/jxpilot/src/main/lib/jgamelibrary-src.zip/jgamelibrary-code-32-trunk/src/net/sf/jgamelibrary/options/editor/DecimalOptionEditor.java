package net.sf.jgamelibrary.options.editor;

import java.awt.BorderLayout;

import javax.swing.JTextField;

import net.sf.jgamelibrary.options.model.DecimalOptionModel;
import net.sf.jgamelibrary.options.option.Option;
import net.sf.jgamelibrary.options.option.DecimalOption;

@SuppressWarnings("serial")
public class DecimalOptionEditor extends OptionEditor<DecimalOption> {

	private DecimalOptionModel model;
	private DecimalOption option;
	
	private JTextField decimalField;
	
	public DecimalOptionEditor(DecimalOptionModel model) {
		super(model);
		this.model = model;
		
		decimalField = new JTextField();
		add(decimalField, BorderLayout.CENTER);
	}
	
	@Override
	public void loadOption(Option option) {
		if(option != null) {
			this.option = (DecimalOption) option;
			decimalField.setText(String.valueOf(this.option.getValue()));
		}
	}
	
	@Override
	public DecimalOption readOption() throws InvalidOptionException {
		double value;
		
		try {
			value = Double.valueOf(decimalField.getText());
		} catch(NumberFormatException e) {
			throw new InvalidOptionException("Input is not a valid decimal.");
		}
		
		Double min = model.getMin();
		if(min != null && value < min)
			throw new InvalidOptionException("The value must at least " + min + ".");
		
		Double max = model.getMax();
		if(max != null && value > max)
			throw new InvalidOptionException("The value must at most " + max + ".");
		
		if(option == null)
			return new DecimalOption(model.getName(), value);
		
		option.setValue(value);
		return option;
	}

}
