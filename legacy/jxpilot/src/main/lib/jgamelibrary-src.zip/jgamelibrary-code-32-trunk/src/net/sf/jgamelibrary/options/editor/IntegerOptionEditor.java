package net.sf.jgamelibrary.options.editor;

import java.awt.BorderLayout;

import javax.swing.JTextField;

import net.sf.jgamelibrary.options.model.IntegerOptionModel;
import net.sf.jgamelibrary.options.option.IntegerOption;
import net.sf.jgamelibrary.options.option.Option;

@SuppressWarnings("serial")
public class IntegerOptionEditor extends OptionEditor<IntegerOption> {

	private IntegerOptionModel model;
	private IntegerOption option;
	
	private JTextField integerField;
	
	public IntegerOptionEditor(IntegerOptionModel model) {
		super(model);
		this.model = model;
		
		integerField = new JTextField();
		add(integerField, BorderLayout.CENTER);
	}
	
	@Override
	public void loadOption(Option option) {
		if(option != null) {
			this.option = (IntegerOption) option;
			integerField.setText(String.valueOf(this.option.getValue()));
		}
	}
	
	@Override
	public IntegerOption readOption() throws InvalidOptionException {
		int value;
		
		try {
			value = Integer.valueOf(integerField.getText());
		} catch(NumberFormatException e) {
			throw new InvalidOptionException("Input is not a valid integer.");
		}
		
		Integer min = model.getMin();
		if(min != null && value < min)
			throw new InvalidOptionException("The value must at least " + min + ".");
		
		Integer max = model.getMax();
		if(max != null && value > max)
			throw new InvalidOptionException("The value must at most " + max + ".");
		
		if(option == null)
			option = new IntegerOption(model.getName(), value);
		else option.setValue(value);
		
		return option;
	}

}
