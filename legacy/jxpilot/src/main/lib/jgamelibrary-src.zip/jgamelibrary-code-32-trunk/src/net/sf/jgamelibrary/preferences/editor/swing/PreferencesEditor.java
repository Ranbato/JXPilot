package net.sf.jgamelibrary.preferences.editor.swing;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import net.sf.jgamelibrary.i18n.JGLI18N;
import net.sf.jgamelibrary.i18n.Namespace;
import net.sf.jgamelibrary.preferences.PreferenceType;
import net.sf.jgamelibrary.preferences.Preferences;
import net.sf.jgamelibrary.preferences.model.Preference;
import net.sf.jgamelibrary.preferences.model.PreferenceSelector;
import net.sf.jgamelibrary.preferences.model.Tab;

/**
 * This class start GUI for editing <code>Preferences</code> in Swing widget
 * library.
 * 
 * @author Taras Kostiak
 * 
 */
public class PreferencesEditor extends JDialog {

    /**
     * Serial version UID.
     */
    private static final long serialVersionUID = 4940153132821088306L;

    /**
     * <code>JGLI18N</code>, where are stored resources such as button names
     * etc.
     */
    private static JGLI18N editorI18N = null;

    /**
     * Namespace for preference's editor i18n resources.
     */
    private static final Namespace EDITOR_NAMESPACE = new Namespace("data",
            "preferencesEditor");

    /*
     * Initializes i18n resources for PreferencesEditor.
     */
    static {
        editorI18N = new JGLI18N(null, JGLI18N.DEFAULT_MISSING_RESOURCE_STRING);

        editorI18N.addNamespace(EDITOR_NAMESPACE);
    }

    /**
     * <code>Preferences</code>, that this window edits.
     */
    private Preferences prefs = null;

    /**
     * All <code>JComponent</code>'s that are built from
     * <code>PreferencesModel</code>, are stored here for parse back, when
     * button "Save" is pressed.
     */
    private Map<String, JComponent> dataContainers = null;

    /**
     * Content panel.
     */
    private JPanel cp = null;

    /**
     * If this thread will be interrupted after <code>PreferencesEditor</code>
     * will be closed(with both "Save" and "Cancel").
     */
    private Thread interruptThread = null;

    /**
     * <code>JGLI18N</code>, to get preference's i18n'zed names.
     */
    private JGLI18N i18n = null;

    /**
     * Namespace, to get preference's i18n'zed names.
     */
    private Namespace ns = null;

    /**
     * Distance between label and input field or previous label and next label.
     */
    private static final int COMPONENT_DISTANCE = 15;

    /**
     * This constructor build the <code>Preferences</code> editing window, with
     * given parameters.
     * 
     * @param prefs
     *            The <code>Preferences</code> to edit.
     * @param alternativeI18N
     *            I18N source to use.
     * @param alternativeI18NNameSpace
     *            I18N namespace to use.
     */
    public PreferencesEditor(Preferences prefs, JGLI18N i18n, Namespace ns,
            Image icon, String title) {
        super((JFrame) null, true);

        if (prefs == null || i18n == null || ns == null || title == null)
            throw new IllegalArgumentException("Arguments can't be null!");

        this.prefs = prefs;
        this.i18n = i18n;
        this.ns = ns;

        setTitle(title);

        dataContainers = new HashMap<String, JComponent>();

        setResizable(false);

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent e) {
                closePreferencesEditor(false);
            }
        });

        if (icon != null)
            setIconImage(icon);

        cp = buildContentPane();
        setContentPane(cp);

        pack();
    }

    /**
     * Builds content panel for this window, as defined by an
     * <code>PreferenceModel</code> given to constructor.
     * 
     * @return Built content panel.
     */
    private JPanel buildContentPane() {
        JPanel cPa = new JPanel();
        cPa.setLayout(new BoxLayout(cPa, BoxLayout.Y_AXIS));

        JTabbedPane tp = new JTabbedPane(JTabbedPane.TOP);
        {
            List<Tab> tabs = prefs.getModel().getTabs();

            for (Tab t : tabs) {
                List<PreferenceSelector> pSelectors = t.getPrefs();

                JPanel tabPanel = new JPanel();
                GridLayout tpl = new GridLayout(0, 2, COMPONENT_DISTANCE,
                        COMPONENT_DISTANCE);
                tabPanel.setLayout(tpl);

                for (PreferenceSelector pSelector : pSelectors) {
                    Preference p = prefs.getModel().getPreferenceBySelector(
                            pSelector);

                    if (p == null) // if no such preference in model(only
                        // selector with such name)
                        continue;

                    JLabel name = new JLabel();
                    name.setText(i18n.get(ns, p.getI18nKey()));
                    tabPanel.add(name);

                    if (p.getType().equals(PreferenceType.TEXT_FIELD)) {
                        int fieldSize = 15;

                        // TODO: This should be fixed with adding options
                        // constraints.

                        // int fieldMaxCharacters = 25;
                        //
                        // if (p.getValue() != null)
                        // try {
                        // int comma = p.getValue().indexOf(',');
                        //
                        // if (comma != -1) {
                        // fieldSize = Integer.parseInt(p.getValue()
                        // .substring(0, comma));
                        // fieldMaxCharacters = Integer.parseInt(p
                        // .getValue().substring(comma + 1));
                        // }
                        // }
                        // catch (Exception e) {
                        // }

                        JTextField input = new JTextField(fieldSize);
                        addDataContainer(p.getName(), input);

                        tabPanel.add(input);
                        input.setText(prefs.get(p.getName()));
                    }
                    else if (p.getType().equals(PreferenceType.BOOLEAN)) {
                        JCheckBox input = new JCheckBox();
                        input.setSelected((prefs.get(p.getName())
                                .equals("true")) ? true : false);

                        addDataContainer(p.getName(), input);

                        tabPanel.add(input);
                    }
                    else if (p.getType().equals(PreferenceType.COMBO_BOX)) {
                        JComboBox input = new JComboBox();

                        String[] vals = p.getValue().split(",");
                        for (String s : vals) {
                            input.addItem(s);

                            if (s.equals(prefs.get(p.getName())))
                                input.setSelectedItem(s);
                        }

                        input.setEditable(false);

                        addDataContainer(p.getName(), input);

                        tabPanel.add(input);
                    }
                    else if (p.getType().equals(PreferenceType.FILE_PATH)) {
                        JTextField pathTextField = new JTextField();
                        pathTextField.setText(prefs.get(p.getName()));
                        addDataContainer(p.getName(), pathTextField);

                        JButton chooseButton = new JButton(editorI18N.get(
                                EDITOR_NAMESPACE,
                                "preferencesEditor.pathChooseButton"));
                        chooseButton
                                .addActionListener(new PathChooseButtonListener(
                                        pathTextField, this));

                        JPanel pathAndButton = new JPanel();
                        BoxLayout pathAndButtonPanelLayout = new BoxLayout(
                                pathAndButton, BoxLayout.X_AXIS);
                        pathAndButton.setLayout(pathAndButtonPanelLayout);
                        pathAndButton.add(pathTextField);
                        pathAndButton.add(chooseButton);

                        tabPanel.add(pathAndButton);
                    }
                }

                Dimension tpD = tpl.preferredLayoutSize(tabPanel);
                tabPanel.setMinimumSize(tpD);
                tabPanel.setMaximumSize(tpD);
                tabPanel.setSize(tpD);

                JPanel pn = new JPanel();
                pn.setLayout(new BoxLayout(pn, BoxLayout.Y_AXIS));
                pn.add(tabPanel);
                pn.add(Box.createVerticalGlue());

                tp.addTab(i18n.get(ns, t.getI18nKey()), pn);
            }
        }

        JPanel bp = new JPanel();
        {
            bp.setLayout(new BoxLayout(bp, BoxLayout.X_AXIS));

            JButton saveButton = new JButton();
            saveButton.setText(editorI18N.get(EDITOR_NAMESPACE,
                    "preferencesEditor.saveButton"));
            saveButton.setSelected(true);
            saveButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    closePreferencesEditor(true);
                }
            });

            JButton cancelButton = new JButton();
            cancelButton.setText(editorI18N.get(EDITOR_NAMESPACE,
                    "preferencesEditor.cancelButton"));
            cancelButton.setSelected(false);
            cancelButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    closePreferencesEditor(false);
                }
            });

            bp.add(Box.createHorizontalGlue());
            bp.add(saveButton);
            bp.add(Box.createRigidArea(new Dimension(3, 0)));
            bp.add(cancelButton);
        }

        cPa.add(tp);
        cPa.add(bp);

        return cPa;
    }

    /**
     * Closes <code>PreferenceEditor</code>.
     * 
     * @param saveOnClose
     *            If true, preferences are saved.
     */
    private void closePreferencesEditor(boolean saveOnClose) {
        if (saveOnClose)
            saveOnClose();

        // TODO: Fix removing this window from XPilotPanelDispatcher.

        // XPilotPanelDispatcher.getDispatcher().removeWindow(this);

        if (interruptThread != null)
            interruptThread.interrupt();

        dispose();
    }

    /**
     * Adds the "data container".
     * 
     * @see #dataContainers
     * 
     * @param name
     *            Identifier of "data container", should be the same as name of
     *            one of preferences in <code>PreferenceModel</code>.
     * @param c
     *            Reference to "data container".
     */
    private void addDataContainer(String name, JComponent c) {
        dataContainers.put(name, c);
    }

    /**
     * Return "data container", by specified name.
     * 
     * @see #dataContainers
     * 
     * @param name
     *            Name of "data container" to return.
     * @return Stored "data container".
     */
    private JComponent getDataContainer(String name) {
        return dataContainers.get(name);
    }

    /**
     * Saves edited preferences to <code>Preferences</code>.
     */
    private void saveOnClose() {
        Set<String> keys = dataContainers.keySet();

        List<Preference> pr = prefs.getModel().getPrefs();

        for (String key : keys) {
            PreferenceType type = null;
            for (Preference p : pr) {
                if (p.getName().equals(key)) {
                    type = p.getType();
                    break;
                }
            }

            String value = null;

            if (type.equals(PreferenceType.TEXT_FIELD)) {
                value = ((JTextField) getDataContainer(key)).getText();
            }
            else if (type.equals(PreferenceType.BOOLEAN)) {
                value = ((JCheckBox) getDataContainer(key)).isSelected() ? "true"
                        : "false";
            }
            else if (type.equals(PreferenceType.COMBO_BOX)) {
                value = (String) ((JComboBox) getDataContainer(key))
                        .getSelectedItem();
            }
            else if (type.equals(PreferenceType.FILE_PATH)) {
                value = ((JTextField) getDataContainer(key)).getText();
            }

            if (value != null)
                prefs.set(key, value);
        }
    }

    /**
     * @see #interruptThread
     */
    public Thread getInterruptThread() {
        return interruptThread;
    }

    /**
     * @see #interruptThread
     */
    public void setInterruptThread(Thread interruptThread) {
        this.interruptThread = interruptThread;
    }

    /**
     * Is used for path choose button listener, that it remembers
     * <code>JTextField</code> to which store selected path by
     * <code>JFileChooser</code>.
     * 
     * @author Taras Kostiak
     * 
     */
    private class PathChooseButtonListener implements ActionListener {

        /**
         * Field to store selected path.
         */
        private JTextField storeField = null;

        /**
         * Window that calls this file chooser.
         */
        private Component callingWindow = null;

        /**
         * Creates new <code>PathChooseButtonListener</code>.
         * 
         * @param storeField
         *            Field to store selected path.
         */
        public PathChooseButtonListener(JTextField storeField,
                Component callingWindow) {
            this.storeField = storeField;
            this.callingWindow = callingWindow;
        }

        /**
         * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser(System.getProperties()
                    .getProperty("user.home"));
            fileChooser.setDialogTitle(editorI18N.get(EDITOR_NAMESPACE,
                    "preferencesEditor.pathChooserTitle"));

            if (fileChooser.showOpenDialog(callingWindow) == JFileChooser.APPROVE_OPTION) {
                storeField.setText(fileChooser.getSelectedFile()
                        .getAbsolutePath());
            }
        }
    }

}
