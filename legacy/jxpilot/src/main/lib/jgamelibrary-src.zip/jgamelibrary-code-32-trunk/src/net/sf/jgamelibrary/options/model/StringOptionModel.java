package net.sf.jgamelibrary.options.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import net.sf.jgamelibrary.options.editor.OptionEditor;
import net.sf.jgamelibrary.options.editor.StringOptionEditor;
import net.sf.jgamelibrary.options.option.StringOption;

@XmlRootElement(name = "string")
public class StringOptionModel extends OptionModel<StringOption> {

	@XmlElement(required = false, name = "min_length")
	private Integer minLength;
	@XmlElement(required = false, name = "max_length")
	private Integer maxLength;
	
	/**
	 * @return The minimum length of the string, or null if n/a.
	 */
	public Integer getMinLength() {return minLength;}
	
	/**
	 * @return The maximum length of the string, or null if n/a.
	 */
	public Integer getMaxLength() {return maxLength;}
	
	@Override
	public OptionEditor<StringOption> getEditor() {return new StringOptionEditor(this);}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				minLength + "\n" +
				maxLength;
	}
}
