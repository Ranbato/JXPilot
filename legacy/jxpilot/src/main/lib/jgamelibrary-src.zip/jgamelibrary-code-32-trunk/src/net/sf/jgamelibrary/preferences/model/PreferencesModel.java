package net.sf.jgamelibrary.preferences.model;

import java.util.List;

import java.net.URL;
import java.net.URLConnection;

import java.io.InputStream;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This class is core of concept, that determines preferences names, types etc
 * and how to build GUI for editing preferences.
 * 
 * @author Taras Kostiak
 * 
 */
@XmlRootElement(name = "preferencesModel")
public class PreferencesModel {

    /**
     * List of <code>Preference</code>'s.
     * 
     * @see Preference
     */
    protected List<Preference> prefs = null;

    /**
     * List of <code>Tab</code>'s.
     * 
     * @see Tab
     */
    protected List<Tab> tabs = null;

    /**
     * Default constructor.
     */
    public PreferencesModel() {
    }

    /**
     * @see #prefs
     */
    @XmlElementWrapper(name = "preferences")
    @XmlElementRef
    public List<Preference> getPrefs() {
        return prefs;
    }

    /**
     * @see #prefs
     */
    public void setPrefs(List<Preference> prefs) {
        this.prefs = prefs;
    }

    /**
     * @see #tabs
     */
    @XmlElementWrapper(name = "tabs")
    @XmlElementRef
    public List<Tab> getTabs() {
        return tabs;
    }

    /**
     * @see #prefs
     */
    public void setTabs(List<Tab> tabs) {
        this.tabs = tabs;
    }

    /**
     * Return <code>Preference</code>, by name specified in given
     * <code>PreferenceSelector</code>.
     * 
     * @param s
     *            <code>PreferenceSelector</code> with name of preference.
     * @return Appropriate <code>Preference</code> or <code>null</code>, if such
     *         preference not found.
     */
    public Preference getPreferenceBySelector(PreferenceSelector s) {
        for (Preference p : prefs) {
            if (p.getName().equals(s.getName()))
                return p;
        }

        return null;
    }

    /**
     * Loads model from xml file from given URL, using JAXB.
     * 
     * @param u
     *            URL to load from.
     * @return Loaded model.
     * @throws IOException
     *             If an IOException occurs.
     * @throws JAXBException
     *             On problems with unmarshalling.
     */
    public static PreferencesModel loadModelFromURL(URL u) throws IOException,
            JAXBException {
        URLConnection c = u.openConnection();

        InputStream is = c.getInputStream();

        PreferencesModel model = loadModelFromInputStream(is);

        is.close();

        return model;
    }

    /**
     * Loads model from xml file from given <code>InputStream</code>, using
     * JAXB.
     * 
     * @param u
     *            URL to load from.
     * @return Loaded model.
     * @throws JAXBException
     *             On problems with unmarshalling.
     */
    public static PreferencesModel loadModelFromInputStream(InputStream is)
            throws JAXBException {
        JAXBContext cn = JAXBContext.newInstance(PreferencesModel.class);
        Unmarshaller unm = cn.createUnmarshaller();

        return (PreferencesModel) unm.unmarshal(is);

    }

}
