package net.sf.jgamelibrary.physics;

import java.util.*;

public class PhysicsEngine<T extends AbstractEntity2D<T>> {
	private List<? extends T> entities;
	private CollisionHandler<? super T> collisionHandler;
	private AbstractCollisionDetector<T> detector;
	
	
	public PhysicsEngine(CollisionHandler<? super T> handler, AbstractCollisionDetector<T> detector) {
		this.collisionHandler = handler;
		this.detector = detector;
	}
	
	public PhysicsEngine(CollisionHandler<? super T> handler) {
		this(handler, new CollisionDetector<T>());
	}
	
	/**
	 * Creates a new PhysicsEngine with the specified entities and CollisionHandler.
	 * Note that the list should have RandomAccess, as get(index) is used frequently.
	 * @param entities The list of entities.
	 * @param handler The collision handler.
	 */
	public PhysicsEngine(List<? extends T> entities, CollisionHandler<? super T> handler)
	{
		this.entities = entities;
		this.collisionHandler = handler;
	}
	
	public PhysicsEngine<T> setEntities(List<? extends T> entities)
	{
		this.entities=entities;
		return this;
	}
	
	public List<? extends T> getEntities(){return entities;}
	
	public PhysicsEngine<T> update(double ticks) {
		rigorousCollisions(ticks);
		return this;
	}
	
	private Collision<T> next = new Collision<T>(), closest = new Collision<T>(), last = new Collision<T>();
	
	private void rigorousCollisions(double ticks) {
		Collision<T> last = null;
		while(findClosestCollision(ticks, last, closest)) {
			updateEntities(closest.ticks*.99);
			collisionHandler.handleCollision(closest);
			ticks-=closest.ticks;
			
			//System.out.println(closest.ticks);
			
			last = this.last.setFrom(closest);
		}
		updateEntities(ticks);
	}
	
	private boolean findClosestCollision(double ticks, Collision<T> last, Collision<T> result) {
		double min_ticks = Double.MAX_VALUE;
		boolean found = false;
		for (int e1 = 0;e1<entities.size();e1++) {
			T entity1 = entities.get(e1);
			
			if(!entity1.isActive()) continue;
			
			for(int e2 =e1+1;e2<entities.size();e2++) {
				T entity2 = entities.get(e2);
				if(!entity2.isActive()) continue;
				if(!entity1.interactsWith(entity2) || !entity2.interactsWith(entity1)) continue;
				if(!entity1.isMobile() && !entity2.isMobile()) continue;
				
				if(detector.calculateCollision(entity1, entity2, ticks, last, next)) {
					if(!found) {
						found = true;
						result.setFrom(next);
						min_ticks = next.ticks;
					} else {
						if(next.ticks<min_ticks) {
							min_ticks = next.ticks;
							result.setFrom(next);
						}
					}
				}
			}
		}
		return found;
	}

	/**
	 * Updates the entities' positions.
	 * @param The amount of time passed.
	 */
	protected void updateEntities(double ticks) {
		for(int i = 0;i<entities.size();i++) {
			T e = entities.get(i);
			if(e.isActive() && e.isMobile()) {
				e.updatePosition(ticks);
				//e.updateVelocity(ticks);
			}
		}
	}
	/**
	 * Updates the entities' velocities.
	 * @param ticks
	 */
	protected void updateVelocities(double ticks)
	{
		for(int i = 0;i<entities.size();i++)
		{
			T e = entities.get(i);
			if(e.isActive() && e.isMobile())
			{
				e.updateVelocity(ticks);
			}
		}
	}
}