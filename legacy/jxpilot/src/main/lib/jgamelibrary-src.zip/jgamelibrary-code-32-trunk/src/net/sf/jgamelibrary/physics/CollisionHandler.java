package net.sf.jgamelibrary.physics;

public interface CollisionHandler<T extends AbstractEntity2D<T>> {
	/**
	 * Handles a collision between two entities.
	 * @param collision The specified collision.
	 */
	public void handleCollision(Collision<? extends T> collision);
}