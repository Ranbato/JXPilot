package net.sf.jgamelibrary.preferences.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This class is used to show what preference to include in tab.
 * 
 * @see Tab
 * 
 * @author Taras Kostiak
 * 
 */
@XmlRootElement(name = "preference")
public class PreferenceSelector {

    /**
     * Shows name of preference to include into this tab.
     */
    protected String name = null;

    /**
     * Default constructor.
     */
    public PreferenceSelector() {
    }

    /**
     * @see #name
     */
    @XmlAttribute(required = true)
    public String getName() {
        return name;
    }

    /**
     * @see #name
     */
    public void setName(String name) {
        this.name = name;
    }

}
