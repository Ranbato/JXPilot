package net.sf.jgamelibrary.physics.test.xpilot;

import net.sf.jgamelibrary.geom.Polygon2D;
import net.sf.jgamelibrary.physics.RotatingEntity2D;

public abstract class XPilotEntity extends RotatingEntity2D<XPilotEntity>{
	
	private boolean mobile;
	
	/**
	 * Mobile entity with mass 1.
	 */
	public XPilotEntity(Polygon2D poly)throws NullPointerException
	{
		this(poly, true);
	}
	
	/*
	 * Mass is set to 1.
	 */
	public XPilotEntity(Polygon2D poly, boolean mobile)throws NullPointerException
	{
		super(1, poly);
		this.mobile = mobile;
	}
	
	/**
	 * Creates a mobile entity.
	 */
	public XPilotEntity(Polygon2D poly,  double mass)throws IllegalArgumentException, NullPointerException
	{
		super(mass, poly);
		mobile = true;
	}
	
	public boolean isMobile() {return mobile;}
	public boolean isBullet() {return false;}
}
