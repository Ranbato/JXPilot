package net.sf.jgamelibrary.graphics;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;

/**
 * Class that uses a {@code BufferStrategy} to render graphics.
 * The frame takes the full screen size by default. In order for
 * the {@code BufferStrategy} to work properly, the frame must be
 * immediately made visible.
 * @author Vlad Firoiu
 * @see {@link BufferStrategy}, {@link JFrame}
 */
public class BufferedFrame extends JFrame {

	public static final long serialVersionUID = 1;
	
	public static final FrameMode DEFAULT_FRAME_MODE = FrameMode.AFS;
	
	private FrameMode frameMode=null;
	
	protected final Toolkit toolkit = Toolkit.getDefaultToolkit();
	protected final Dimension screenSize = toolkit.getScreenSize();
	
	public BufferedFrame() {
		this(DEFAULT_FRAME_MODE);
	}

	public BufferedFrame(FrameMode mode) {
		super(Accelerator.gfxConfig);
		initFrameMode(mode);
	}
	
	public FrameMode getFrameMode() {return frameMode;}
	
	//graphics stuff
	private final int NUM_BUFFERS = 2;
	private GraphicsDevice gd=Accelerator.gfxDevice;
	private BufferStrategy bufferStrategy;
	
	private void initFrameMode(FrameMode mode) {
		if(!setFrameMode(mode)) {
			mode = DEFAULT_FRAME_MODE;
			setFrameMode();
		}
		setBufferStrategy();
	}
	
	/**
	 * Switched the frame mode.
	 * @param mode The new mode.
	 * @return Whether the switch was successful.
	 */
	private boolean setFrameMode(FrameMode mode) {
		if(mode == frameMode) return true;
		
		if (mode == FrameMode.FSEM && !gd.isFullScreenSupported()) {
			return false;
		}
		
		this.frameMode = mode;
		setFrameMode();
		return true;
	}
	
	private void setFrameMode() {
		switch(frameMode)
		{
		case FSEM:
			this.setUndecorated(true);
			this.setIgnoreRepaint(true);
			this.setResizable(false);
			
			if (!gd.isFullScreenSupported()) {
				System.out.println("FSEM not supported.");
				System.exit(0);
			}
			gd.setFullScreenWindow(this);
		break;
		case UFS:
			this.setUndecorated(true);
		case AFS:
			this.setIgnoreRepaint(true);
			this.setSize(screenSize);
			this.setVisible(true);
			this.setResizable(true);
		break;
		}
	}
	
	private void setBufferStrategy() {
		try {
			EventQueue.invokeAndWait(new Runnable() {
				public void run() {
					BufferedFrame.this.createBufferStrategy(NUM_BUFFERS);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error while creating buffer strategy.");
			System.exit(0);
		}
		
		try {
			Thread.sleep(500);
		} catch(InterruptedException e){}
		
		bufferStrategy = this.getBufferStrategy();
	}
	
	private void restoreScreen() {
		Window w = gd.getFullScreenWindow();
		if(w!=null) {
			w.dispose();
		}
		gd.setFullScreenWindow(null);
	}
	
	/**
	 * Restores screen and disposes of this frame.
	 */
	public void finish() {
		if (frameMode==FrameMode.FSEM) {
			restoreScreen();
		}
		this.dispose();
	}

	/**
	 * Displays the graphics. This simply calls render(Graphics2D) on the appropriate draw graphics.
	 */
	public void activeRender() {
		do {
			// The following loop ensures that the contents of the drawing buffer
			// are consistent in case the underlying surface was recreated
			do {
				// Get a new graphics context every time through the loop
				// to make sure the strategy is validated
				Graphics2D graphics = (Graphics2D) bufferStrategy.getDrawGraphics();

				// Render to graphics
				render(graphics);

				// Dispose the graphics
				graphics.dispose();

				// Repeat the rendering if the drawing buffer contents 
				// were restored
			} while (bufferStrategy.contentsRestored());

			// Display the buffer
			bufferStrategy.show();
			
			//for linux
			toolkit.sync();

		// Repeat the rendering if the drawing buffer was lost
		} while (bufferStrategy.contentsLost());
	}
	
	/**
	 * This method should be overridden to display graphics.
	 * @param g2d The Graphics object to render on.
	 */
	protected void render(Graphics2D g2d){super.paint(g2d);}
}