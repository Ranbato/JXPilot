package net.sf.jgamelibrary.options.editor;

import javax.swing.JTextField;

import net.sf.jgamelibrary.options.model.StringOptionModel;
import net.sf.jgamelibrary.options.option.Option;
import net.sf.jgamelibrary.options.option.StringOption;

@SuppressWarnings("serial")
public class StringOptionEditor extends OptionEditor<StringOption> {

	private StringOptionModel model;
	private StringOption option;
	
	private JTextField stringField;
	
	public StringOptionEditor(StringOptionModel model) {
		super(model);
		this.model = model;
		
		stringField = new JTextField();
		add(stringField);
	}

	@Override
	public void loadOption(Option option) {
		if(option != null) {
			this.option = (StringOption) option;
			stringField.setText(this.option.getValue());
		}
	}
	
	@Override
	public StringOption readOption() throws InvalidOptionException {
		String value = stringField.getText();
		
		Integer minLength = model.getMinLength();
		if(minLength != null && value.length() < minLength)
			throw new InvalidOptionException("Length must be at least " + minLength + ".");
		
		Integer maxLength = model.getMaxLength();
		if(maxLength != null && value.length() > maxLength)
			throw new InvalidOptionException("Length must be at most " + maxLength + ".");
		
		if(option == null)
			option = new StringOption(model.getName(), value);
		else option.setValue(value);
		
		return option;
	}

}
