package net.sf.jgamelibrary.geom;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import net.sf.jgamelibrary.graphics.Renderable;

public abstract class Line2D extends java.awt.geom.Line2D implements Renderable {
	private Rectangle2D bounds;
	
	public Line2D() {
		bounds = new Rectangle2D.Double();
	}
	
	public void setLine(double x1, double y1, double x2, double y2) {
		getV1().setLocation(x1, y1);
		getV2().setLocation(x2, y2);
		updateBounds();
	}
	
	public double getX1(){return getV1().getX();}
	public double getY1(){return getV1().getY();}
	public double getX2(){return getV2().getX();}
	public double getY2(){return getV2().getY();}
	
	public Point2D getP1(){return getV1();}
	public Point2D getP2(){return getV2();}
	
	public abstract Vector2D getV1();
	public abstract Vector2D getV2();
	
	public Rectangle2D getBounds2D(){return bounds;}
	
	private Rectangle2D calculateBounds() {
		bounds.setFrameFromDiagonal(getV1(), getV2());
		return bounds;
	}
	
	/**
	 * Should be called by subclasses when the line's state changes.
	 */
	protected void updateBounds(){calculateBounds();}
	
	public Line2D translate(double dx, double dy) {
		getV1().add(dx,dy);
		getV2().add(dx,dy);
		updateBounds();
		return this;
	}
	
	public Line2D translate(Vector2D amount) {
		getV1().add(amount);
		getV2().add(amount);
		updateBounds();
		return this;
	}
	
	public void render(Graphics g) {
		g.drawLine((int)Math.round(getX1()), -(int)Math.round(getY1()), (int)Math.round(getX2()), -(int)Math.round(getY2()));
	}
	
	@Override
	public void render(Graphics2D g2d){render((Graphics)g2d);}
	
	public void draw(Graphics g) {
		g.drawLine((int)getX1(), -(int)getY1(), (int)getX2(), -(int)getY2());
	}
	
	public void draw(Graphics g, int x, int y) {
		g.drawLine(x+(int)getX1(), -(y+(int)getY1()), x+(int)getX2(), -(y+(int)getY2()));
	}
	
	public void draw(Graphics g, double x, double y) {
		g.drawLine((int)(x+getX1()), -(int)(y+getY1()), (int)(x+getX2()), -(int)(y+getY2()));
	}
	
}