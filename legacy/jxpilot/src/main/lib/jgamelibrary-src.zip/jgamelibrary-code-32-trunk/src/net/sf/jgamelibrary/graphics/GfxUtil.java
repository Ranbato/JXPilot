package net.sf.jgamelibrary.graphics;

import java.awt.Graphics;
//import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Rectangle2D;

/**
 * Miscellaneous useful graphics functions for converting from Cartesian space to user space.
 * @author Vlad Firoiu
 */
public class GfxUtil {
	/**
	 * Draws the specified String correctly taking into account inverted y-axes.
	 * @param str The String to draw.
	 * @param x The x-coordinate, in Cartesian coordinates.
	 * @param y The y-coordinate, in Cartesian coordinates.
	 * @param g The Graphics context.
	 */
	public static void drawString(String str, int x, int y, Graphics g) {
		g.drawString(str, x, -y);
	}
	
	public static void drawCenteredStringRight(String str, int x, int y, Graphics g) {
		drawString(str, x, y - g.getFontMetrics().getHeight()/2, g);
	}
	
	public static void drawCenteredStringLeft(String str, int x, int y, Graphics g) {
		Rectangle2D bounds = g.getFontMetrics().getStringBounds(str, g);
		drawString(str, (int)(x-bounds.getWidth()), (int)(y-bounds.getHeight()/2.0), g);
	}
	
	public static void drawCenteredStringUp(String str, int x, int y, Graphics g) {
		Rectangle2D bounds = g.getFontMetrics().getStringBounds(str, g);
		drawString(str, (int)(x-bounds.getWidth()/2.0), y, g);
	}
	
	public static void drawCenteredStringDown(String str, int x, int y, Graphics g) {
		Rectangle2D bounds = g.getFontMetrics().getStringBounds(str, g);
		drawString(str, (int)(x-bounds.getWidth()/2.0), (int)(y-bounds.getHeight()), g);
	}
	
	public static void drawImage(Image img, int x, int y, Graphics g) {
		g.drawImage(img, x, -(y+img.getHeight(null)), null);
	}
	
	public static void drawCenteredImage(Image img, int x, int y, Graphics g) {
		g.drawImage(img, x-(img.getWidth(null) >> 1), (img.getHeight(null) >> 1) - y, null);
	}
	
	public static void drawLine(int x1, int y1, int x2, int y2, Graphics g) {
		g.drawLine(x1, -y1, x2, -y2);
	}
	
	public static void drawRect(int x, int y, int width, int height, Graphics g) {
		g.drawRect(x, -(y+height), width, height);
	}
	
	public static void fillRect(int x, int y, int width, int height, Graphics g) {
		g.fillRect(x, -(y+height), width, height);
	}
	
	public static void drawCenteredRect(int x, int y, int width, int height, Graphics g) {
		g.drawRect(x - (width >> 1), (height >> 1) - y, width, height);
	}
	
	public static void fillCenteredRect(int x, int y, int width, int height, Graphics g) {
		g.fillRect(x - (width >> 1), -((height >> 1) + y), width, height);
	}
	
	public static void drawOval(int x, int y, int width, int height, Graphics g) {
		g.drawOval(x, -(y+height), width, height);
	}
	
	public static void fillOval(int x, int y, int width, int height, Graphics g) {
		g.fillOval(x, -(y+height), width, height);
	}
	
	public static void drawCenteredOval(int x, int y, int width, int height, Graphics g) {
		g.drawOval(x - (width >> 1), -((height >> 1) + y), width, height);
	}
	
	public static void fillCenteredOval(int x, int y, int width, int height, Graphics g) {
		g.fillOval(x - (width >> 1), -((height >> 1) + y), width, height);
	}
}
