package net.sf.jgamelibrary.options.option;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "enum")
public class EnumOption extends Option {
	
	@XmlElement(name = "value")
	private String value;

	EnumOption() {}
	
	public EnumOption(String name, String value) {
		super(name);
		setValue(value);
	}
	
	public String getValue() {return value;}

	public void setValue(String value) {this.value = value;}	
	
}
