package net.sf.jgamelibrary.options.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import net.sf.jgamelibrary.options.editor.OptionEditor;
import net.sf.jgamelibrary.options.option.Option;

/**
 * Base class for option models.
 * @author Vlad Firoiu
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
public abstract class OptionModel<T extends Option> {
	
	@XmlElement
	private String name;
	
	@XmlElement
	private String description;
	
	protected OptionModel() {}
	
	/**
	 * @return The name of this option.
	 */
	public String getName() {return name;}
	
	/**
	 * @return A description of this option.
	 */
	public String getDescription() {return description;}
	
	public abstract OptionEditor<T> getEditor();
	
	@Override
	public String toString() {
		return name + "\n" + description;
	}
}
