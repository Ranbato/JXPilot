package net.sf.jgamelibrary.physics;

public interface AbstractRotatingEntity2D<T extends AbstractRotatingEntity2D<T>> extends AbstractEntity2D<T> {
	public void setAngle(double angle);
	public double getAngle();
	public void rotate(double angle);
}
