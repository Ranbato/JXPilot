package net.sf.jgamelibrary.physics.test.xpilot;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.util.*;

import net.sf.jgamelibrary.graphics.*;
import net.sf.jgamelibrary.geom.Vector2D;

public class XPilotFrame extends BufferedFrame {
	
	public static void main(String[] args) {
		new XPilotFrame().setVisible(true);
	}
	
	private XPilotEngine engine;
	private Timer timer;
	private KeyboardInput input;
	
	private long start_time;
	private long loops = 0;
	
	private final double FPS = 50.0;
	
	private Vector2D viewCenter, centerScale, scaleFactor;
	private XPilotRenderer renderer = new XPilotRenderer();
	
	public XPilotFrame() {
		super(FrameMode.AFS);
		
		//super.setViewCenter(0, 0);
		//super.setCenterScale(0.5, 0.5);
		//super.setScaleFactor(0.7);
		
		viewCenter = new Vector2D(0,0);
		centerScale = new Vector2D(0.5, 0.5);
		scaleFactor = new Vector2D(0.7, 0.7);
		
		input = new KeyboardInput();
		super.addKeyListener(input);
		engine = new XPilotEngine(input);
		
		super.addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode()==KeyEvent.VK_ESCAPE)
				{
					timer.cancel();
					XPilotFrame.super.finish();
					
					double run_time = (double)(System.currentTimeMillis()-start_time)/1000.0;
					
					System.out.println("Ran for " + run_time + " seconds." + 
										"\nNumber of frames was " + loops +
										"\nAverage FPS was " + (double)loops/run_time);
				}
			}
		});
		
		timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask(){
			private long last_execution;
			private boolean first = true;
			
			public void run()
			{
				long time = System.currentTimeMillis();
				if(first) {
					first = false;
					start_time = time;
				} else {
					engine.update((double)(time-last_execution)/1000.0);
					//XPilotFrame.super.setViewCenter(engine.ship.getPosition());
					XPilotFrame.super.activeRender();
					loops++;
				}
				last_execution = time;
			}
		}, 500, Math.round(1000.0/FPS));
		
		/*
		DisplayMode current = Accelerator.gfxDevice.getDisplayMode();
		try
		{
			Accelerator.gfxDevice.setDisplayMode(new DisplayMode(800,600,32,DisplayMode.REFRESH_RATE_UNKNOWN));
		}
		catch(UnsupportedOperationException e)
		{
			Accelerator.gfxDevice.setDisplayMode(new DisplayMode(800,600,32,DisplayMode.REFRESH_RATE_UNKNOWN));
		}
		*/
	}
	
	@Override
	protected void render(Graphics2D g) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, super.getWidth(), super.getHeight());
		
		renderer.setDrawTransform(g);
		
		g.setColor(Color.WHITE);

		List<? extends XPilotEntity> entities = engine.getEntities();
		for(int i = 0;i<entities.size();i++) {
			XPilotEntity e = entities.get(i);
			if(e.isActive()) e.render(g);
		}
		
		//GfxUtil.drawString("Drawing @ (100,100)", 100, 100, g);
		//GfxUtil.drawString("Drawing @ 00,00", 00, 00, g);
	}
	
	private class XPilotRenderer extends AbstractRenderer {

		@Override
		protected Vector2D getCenterScale() {
			return centerScale;
		}

		@Override
		protected int getHeight() {
			return XPilotFrame.super.getHeight();
		}

		@Override
		protected Vector2D getScaleFactor() {
			return scaleFactor;
		}

		@Override
		protected Point2D getViewCenter() {
			return viewCenter;
		}

		@Override
		protected int getWidth() {
			return XPilotFrame.super.getWidth();
		}
		
		@Override
		public void setDrawTransform(Graphics2D g) {
			super.setDrawTransform(g);
		}
	}
	
	private static class KeyboardInput extends KeyAdapter implements PlayerInput {
		private boolean thrusts, turns_left, turns_right, fires_shot;
		
		public boolean thrusts() {return thrusts;}
		public boolean turnsLeft() {return turns_left;}
		public boolean turnsRight() {return turns_right;}
		public boolean firesShot() {return fires_shot;}
		
		@Override
		public void keyPressed(KeyEvent e) {
			int key = e.getKeyCode();
			
			switch(key) {
			case KeyEvent.VK_A:
				turns_right = false;
				turns_left = true;
				break;
			case KeyEvent.VK_S:
				turns_left = false;
				turns_right = true;
				break;
			case KeyEvent.VK_SHIFT:
				thrusts = true;
				break;
			case KeyEvent.VK_ENTER:
				fires_shot = true;
				break;
			}
		}
		
		@Override
		public void keyReleased(KeyEvent e) {
			int key = e.getKeyCode();
			
			switch(key) {
			case KeyEvent.VK_A:
				turns_left = false;
				break;
			case KeyEvent.VK_S:
				turns_right = false;
				break;
			case KeyEvent.VK_SHIFT:
				thrusts = false;
				break;
			case KeyEvent.VK_ENTER:
				fires_shot = false;
				break;	
			}
		}
	}
}