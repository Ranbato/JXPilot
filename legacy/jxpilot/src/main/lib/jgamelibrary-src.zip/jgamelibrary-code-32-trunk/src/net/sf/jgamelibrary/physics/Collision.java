package net.sf.jgamelibrary.physics;

import java.util.Comparator;

import net.sf.jgamelibrary.geom.Line2D;
import net.sf.jgamelibrary.geom.Vector2D;

/**
 * Describes a collision between two entities.
 * @author Vlad Firoiu
 */
public class Collision<T extends AbstractEntity2D<T>> implements AbstractCollision<T> {
	public static final Comparator<Collision<?>> INCREASING_TICKS =
		new Comparator<Collision<?>>(){
		public int compare(Collision<?> c1, Collision<?> c2) {
			return Double.compare(c1.ticks, c2.ticks);
		}
	};
	public static final Comparator<Collision<?>> DECREASING_TICKS =
		new Comparator<Collision<?>>(){
		public int compare(Collision<?> c1, Collision<?> c2) {
			return Double.compare(c2.ticks, c1.ticks);
		}
	};
	
	/**
	 * The main colliding entity.
	 */
	T incident,
	/**
	 * The entity main collides with.
	 */
	target;
	
	/**
	 * The vertex of entity that hits the target.
	 */
	Vector2D vertex;
	/**
	 * The edge of the target hit by the entity.
	 */
	Line2D edge;
	
	/**
	 * The location of the collision.
	 */
	Vector2D location;
	/**
	 * Amount of time it takes main to hit with.
	 */
	double ticks;
	
	public Collision() {
		location = new Vector2D();
	}
	
	public Collision(Collision<? extends T> other) {
		this();
		setFrom(other);
	}
	
	public T getIncident() {return incident;}
	public void setIncident(T entity) {this.incident = entity;}
	
	public T getTarget() {return target;}
	public void setTarget(T target) {this.target = target;}
	
	public Vector2D getVertex() {return vertex;}
	public void setVertex(Vector2D vertex) {this.vertex = vertex;}
	
	public Line2D getEdge() {return edge;}
	public void setEdge(Line2D edge) {this.edge = edge;}
	
	public Vector2D getLocation() {return location;}
	public void setLocation(Vector2D location) {this.location.setFrom(location);}
	
	public double getTicks() {return ticks;}
	public void setTicks(double ticks) {this.ticks = ticks;}
	
	public Collision<T> setCollision(T entity, T target, Vector2D vertex, Line2D edge, Vector2D location, double ticks) {
		this.incident = entity;
		this.target = target;
		this.vertex = vertex;
		this.edge = edge;
		this.location.setFrom(location);
		this.ticks = ticks;
		return this;
	}
	
	public Collision<T> setFrom(Collision<? extends T> other) {
		return setCollision(other.incident, other.target, other.vertex, other.edge, other.location, other.ticks);
	}
	
	public T getOther(T entity) {
		if(entity==this.incident) return target;
		if(entity==target) return this.incident;
		return null;
	}
	
	/*
	public Collision<T> setLastCollisions()
	{
		entity.last_collision=edge;
		//target.last_collision=edge;
		return this;
	}
	*/
}