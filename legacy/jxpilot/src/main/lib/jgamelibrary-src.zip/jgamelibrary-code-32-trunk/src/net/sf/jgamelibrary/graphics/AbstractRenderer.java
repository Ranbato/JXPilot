package net.sf.jgamelibrary.graphics;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import net.sf.jgamelibrary.geom.Vector2D;

/**
 * Manages rendering of {@code Renderable} objects.
 * @author Vlad Firoiu
 */
public abstract class AbstractRenderer {
	
	private AffineTransform drawTransform = new AffineTransform();
	
	/**
	 * Calculates the AffineTransform needed to draw correctly.
	 * @return The newly calculated AffineTransform.
	 */
	public AffineTransform getDrawTransform() {
		drawTransform.setToIdentity();
		
		drawTransform.translate(getCenterScale().getX()*getWidth(), getCenterScale().getY()*getHeight());
		drawTransform.scale(getScaleFactor().getX(), getScaleFactor().getY());
		drawTransform.translate(-getViewCenter().getX(), getViewCenter().getY());
		
		return drawTransform;
	}
	
	/**
	 * Sets the correct draw transform for rendering Renderable objects.
	 * @param g The Graphics2D object to set.
	 */
	public void setDrawTransform(Graphics2D g) {g.setTransform(getDrawTransform());}
	
	/**
	 * The width of draw area.
	 */
	protected abstract int getWidth();
	/**
	 * The height of the draw area.
	 */
	protected abstract int getHeight();
	/**
	 * Where the center should appear in user space, in terms of the frame size.
	 * For example, if centerScale = (0,0), the viewCenter will be drawn in the 
	 * upper left corner of the frame, but if centerScale = (0.5,0.5), the viewCenter
	 * will be drawn in the center of the frame.
	 */
	protected abstract Vector2D getCenterScale();
	/**
	 * The scale factors for drawing in the x and y directions.
	 */
	protected abstract Vector2D getScaleFactor();
	/**
	 * The center in the virtual world.
	 */
	protected abstract Point2D getViewCenter();
}
