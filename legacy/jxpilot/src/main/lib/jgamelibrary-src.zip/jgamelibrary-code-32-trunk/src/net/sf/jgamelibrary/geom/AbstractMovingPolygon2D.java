package net.sf.jgamelibrary.geom;

import java.awt.Polygon;
import java.awt.geom.Point2D;
import java.util.Collection;

public abstract class AbstractMovingPolygon2D extends Polygon2D {
	protected AbstractMovingPolygon2D() {
		super();
	}

	protected AbstractMovingPolygon2D(Collection<? extends Point2D> points) {
		super(points);
	}

	protected AbstractMovingPolygon2D(double[] xpoints, double[] ypoints, int npoints) {
		super(xpoints, ypoints, npoints);
	}

	protected AbstractMovingPolygon2D(int sides) {
		super(sides);
	}

	protected AbstractMovingPolygon2D(int[] xpoints, int[] ypoints, int npoints) {
		super(xpoints, ypoints, npoints);
	}

	protected AbstractMovingPolygon2D(Point2D... points) {
		super(points);
	}

	protected AbstractMovingPolygon2D(Polygon other) {
		super(other);
	}

	protected AbstractMovingPolygon2D(AbstractPolygon2D other) {
		super(other);
	}

	/**
	 * Default UID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The orientation of this polygon.
	 * @return The angle, in radians.
	 */
	protected abstract double getAngle();
	
	/**
	 * @return The position of this polygon.
	 */
	protected abstract Vector2D getPosition();
	
	/**
	 * @return The template polygon.
	 */
	protected abstract AbstractPolygon2D getTemplate();
	
	/**
	 * Updates the bounding polygon.
	 */
	protected void updatePolygon() {
		resetPolygon();
		if(getAngle()!=0.0) {
			for(int i = 0;i<super.numVertices();i++) {
				super.getVertex(i).rotate(getAngle());
			}
		}
		for(int i = 0;i<super.numVertices();i++) {
			super.getVertex(i).add(getPosition());
		}
		super.updateBounds();
	}
	
	/**
	 * Sets polygon to be the same as the template.
	 */
	protected void resetPolygon() {
		for(int i = 0;i<getTemplate().numVertices();i++) {
			super.setVertex(i,getTemplate().getVertex(i));
		}
	}
	
	@Override
	public AbstractMovingPolygon2D clone() {return (AbstractMovingPolygon2D) super.clone();}
}
