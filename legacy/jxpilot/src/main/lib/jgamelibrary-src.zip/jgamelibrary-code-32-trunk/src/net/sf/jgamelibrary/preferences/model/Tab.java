package net.sf.jgamelibrary.preferences.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This class determines how to build an tab for GUI.
 * 
 * @author Taras Kostiak
 * 
 */
@XmlRootElement(name = "tab")
public class Tab {

    /**
     * Name of tab to display.
     */
    protected String name = null;

    /**
     * What i18n key use for name of this preference in GUI.
     */
    protected String i18nKey = null;

    /**
     * List of preferences in this tab.
     */
    protected List<PreferenceSelector> prefs = null;

    /**
     * Default constructor.
     * 
     */
    public Tab() {
    }

    /**
     * @see #name
     */
    @XmlAttribute(required = true)
    public String getName() {
        return name;
    }

    /**
     * @see #name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @see #prefs
     */
    @XmlElementRef
    public List<PreferenceSelector> getPrefs() {
        return prefs;
    }

    /**
     * @see #prefs
     */
    public void setPrefs(List<PreferenceSelector> prefs) {
        this.prefs = prefs;
    }

    /**
     * Returns key for i18n depending on its value.<br>
     * If not specified then <code>preferences.tab.NAME</code> will be
     * used(where NAME is {@link #name}).
     * 
     * @return Key for i18n.
     * 
     * @see #i18nKey
     */
    @XmlAttribute
    public String getI18nKey() {
        return (i18nKey != null) ? (i18nKey) : ("preferences.tab." + name);
    }

    /**
     * @see #i18nKey
     */
    public void setI18nKey(String key) {
        i18nKey = key;
    }

}
