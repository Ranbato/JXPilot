package net.sf.jgamelibrary.physics;

import net.sf.jgamelibrary.geom.*;
import net.sf.jgamelibrary.graphics.Renderable;

public interface AbstractEntity2D <T extends AbstractEntity2D<T>> extends Renderable {
	public abstract boolean isActive();
	public abstract boolean isMobile();
	public abstract boolean interactsWith(T other);

	public abstract Vector2D getPosition();
	public abstract Vector2D getVelocity();
	public abstract void updatePosition(double ticks);
	public abstract void updateVelocity(double ticks);
	
	public abstract AbstractPolygon2D getBounds();
}
