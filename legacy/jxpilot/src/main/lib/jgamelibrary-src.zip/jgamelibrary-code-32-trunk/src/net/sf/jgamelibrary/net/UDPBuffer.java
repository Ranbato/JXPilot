package net.sf.jgamelibrary.net;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import net.sf.jgamelibrary.util.ByteBuffer;

/**
 * Wraps {@code DatagramPacket} to provide some utility methods.
 * @author Vlad Firoiu
 */
public class UDPBuffer extends ByteBuffer {
	
	/**
	 * The underlying UDP packet.
	 */
	public final DatagramPacket packet;
	
	public UDPBuffer(int capacity) {
		super(capacity);
		packet = new DatagramPacket(buf, capacity);
	}
	
	/**
	 * Sends the contents of this buffer. The buffer remains unchanged.
	 * @param socket The socket to send through.
	 * @throws IOException Passes along exceptions thrown by {@link DatagramSocket#send(DatagramPacket)}
	 * @return The number of bytes sent.
	 */
	public int send(DatagramSocket socket) throws IOException {
		packet.setData(buf, reader, length());
		if(socket.isConnected()) packet.setSocketAddress(socket.getRemoteSocketAddress());
		socket.send(packet);
		return packet.getLength();
	}
	
	/**
	 * Receives a UDP packet into this buffer. The data is written at the writer position.
	 * @param socket The socket to receive from.
	 * @throws IOException Passes along exceptions thrown by {@link DatagramSocket#receive(DatagramPacket)}
	 * @return The number of bytes received.
	 */
	public int receive(DatagramSocket socket) throws IOException {
		packet.setData(buf, writer, remaining());
		socket.receive(packet);
		writer += packet.getLength();
		return packet.getLength();
	}
}
