package net.sf.jgamelibrary.physics;

public interface AbstractCollisionDetector<T extends AbstractEntity2D<T>> {
	/**
	 * Calculates the first collision between two entities in a given time frame.
	 * @param e1 The first entity.
	 * @param e2 The second entity.
	 * @param ticks The time frame.
	 * @param last The last collision, to prevent duplicate finds.
	 * @param result The resulting collision.
	 * @return Whether a collision was found.
	 */
	public boolean calculateCollision(T e1, T e2,double ticks, Collision<T> last, Collision<T> result);
}
