package net.sf.jgamelibrary.graphics;

public enum FrameMode {
	
	/**
	 * Full Screen Exclusive Mode
	 */
	FSEM,
	/**
	 * Undecorated Full Screen
	 */
	UFS, 
	 /**
	  * Almost Full Screen
	  */
	 AFS;
}
