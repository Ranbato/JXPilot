package net.sf.jgamelibrary.physics.test.xpilot;

import java.util.ArrayList;
import net.sf.jgamelibrary.geom.Polygon2D;
import net.sf.jgamelibrary.geom.Vector2D;

public class Ship extends XPilotEntity {

	public static final double SHIP_RADIUS = 16.0;
	private static final Polygon2D DEFAULT_SHAPE = new Polygon2D().
		addVertex(new Vector2D().setPolar(SHIP_RADIUS, 0.0)).
		addVertex(new Vector2D().setPolar(SHIP_RADIUS, 3.0 * Math.PI / 4.0)).
		addVertex(new Vector2D().setPolar(SHIP_RADIUS, -3.0 * Math.PI / 4.0));
	private static final double DEFAULT_MASS = 4.0;
	public static final int NUM_BULLETS = 15;
	public static final double BULLET_SPEED = 500.0;
	/**
	 * The time it takes to cool down between shots, in milliseconds.
	 */
	public static final double COOLDOWN_TIME = 100.0;
	
	private Vector2D thrust = new Vector2D();
	private double thrust_power = 4000.0;
	final ArrayList<Bullet> bullets;
	private double last_shot_time=0;
	
	public Ship(Polygon2D bounds, double mass) throws IllegalArgumentException,
			NullPointerException {
		super(bounds, mass);
		bullets = new ArrayList<Bullet>(NUM_BULLETS);
		for(int i = 0;i<NUM_BULLETS;i++) {
			bullets.add(new Bullet());
		}
	}
	
	public Ship() {this(DEFAULT_SHAPE,DEFAULT_MASS);}
	
	public boolean isActive(){return true;}
	public boolean interactsWith(XPilotEntity other){return true;}
	
	public Ship thrust(double power, double ticks)
	{
		super.applyForce(thrust.setPolar(thrust_power, super.getAngle()), ticks);
		return this;
	}
	
	public Ship thrust(double ticks){return thrust(thrust_power, ticks);}
	
	public boolean fireShot() {
		double time = System.currentTimeMillis();
		if(time > last_shot_time + COOLDOWN_TIME) {
			for(int i = 0;i<bullets.size();i++) {
				Bullet b = bullets.get(i);
				if(!b.isActive()) {
					fireShot(b);
					last_shot_time = time;
					return true;
				}
			}
		}
		return false;
	}

	private Vector2D bulletPosition = new Vector2D(), bulletVelocity = new Vector2D();
	private void fireShot(Bullet b) {
		b.active = true;
		
		bulletPosition.setPolar(SHIP_RADIUS + Bullet.BULLET_RADIUS + 1.0, this.getAngle());
		bulletPosition.add(this.getPosition());
		b.setPosition(bulletPosition);
		
		bulletVelocity.setPolar(BULLET_SPEED, this.getAngle());
		bulletVelocity.add(this.getVelocity());
		b.setVelocity(bulletVelocity);
	}
}
