package net.sf.jgamelibrary.geom;

import java.awt.geom.Point2D;

public enum Intersection {
	PARALLEL, COINCIDENT, NOT_INTERSECTING, INTERSECTING;
	
	/**
	 * Attempts to find an intersection between the points.
	 * @param l1 The first segment.
	 * @param l2 The second segment.
	 * @param result The point of intersection, if it exists.
	 * The point is set to the line's intersection even if the actual segments do not intersect.
	 * @return The type of intersection.
	 */
	public static Intersection getIntersection(java.awt.geom.Line2D l1, java.awt.geom.Line2D l2, Point2D result) {
		return getIntersection(l1.getX1(), l1.getY1(), l1.getX2(), l1.getY2(),
							l2.getX1(), l2.getY1(), l2.getX2(), l2.getY2(), result);
	}
	
	public static Intersection getIntersection(Point2D p1, Point2D p2, Point2D p3, Point2D p4, Point2D result) {
		return getIntersection(p1.getX(), p1.getY(), p2.getX(), p2.getY(), 
						p3.getX(), p3.getY(), p4.getX(), p4.getY(), result);
	}
	
	public static Intersection getIntersection(double x1, double y1, double x2, double y2,
											double x3, double y3, double x4, double y4, Point2D result)
	{
		double denominator = (y4-y3)*(x2-x1) - (x4-x3)*(y2-y1);
		double numerator1 = (x4-x3)*(y1-y3) - (y4-y3)*(x1-x3);
		double numerator2 = (x2-x1)*(y1-y3) - (y2-y1)*(x1-x3);

		if(denominator==0.0) {
			if(numerator1==0.0 && numerator2==0) return Intersection.COINCIDENT;
			else return Intersection.PARALLEL;
		}

		double u1 = numerator1/denominator;
		double u2 = numerator2/denominator;

		result.setLocation(x1+u1*(x2-x1), y1+u1*(y2-y1));

		if(0<=u1 && u1<=1 && 0<=u2 && u2<=1) return Intersection.INTERSECTING;
		else return Intersection.NOT_INTERSECTING;
	}
}
