package net.sf.jgamelibrary.i18n;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * This is core class for managing i18n in JGameLibrary.
 * 
 * @author Taras Kostiak
 * 
 */
public class JGLI18N {

    /**
     * Default string for showing as i18n'lised value, when resource couldn't be
     * found in any case.
     */
    public static String DEFAULT_MISSING_RESOURCE_STRING = "I18N_ERROR";

    /**
     * Namespaces managed by this <code>JGLI18N</code>.
     */
    protected List<Namespace> namespaces = null;

    /**
     * Current locale.
     * 
     * @see #get(Namespace, String)
     */
    protected Locale locale = null;

    /**
     * Is showed as i18n'lised value, when resource can't be found.
     */
    protected String missingResourceString = null;

    /**
     * Stores <code>XmlRBC</code>'s per each bundle path.<br>
     * Since there can be multiple basenames per one bundle path.
     */
    protected Hashtable<String, XmlRBC> controls = null;

    /**
     * Creates new <code>JGLI18N</code> with default locale for returning
     * resources with {@link #get(String)}.
     * 
     * @param namespaces
     *            Pairs of bundle paths and base names. Can be <code>null</code>
     *            , but you need add namespaces manually later.
     * @param missingResourceString
     *            Is showed as i18n'lised value, when resource can't be found.
     */
    public JGLI18N(List<Namespace> namespaces, String missingResourceString) {
        this(namespaces, Locale.getDefault(), missingResourceString);
    }

    /**
     * Creates new <code>JGLI18N</code>.
     * 
     * @param namespaces
     *            Pairs of bundle paths and base names. Can be <code>null</code>
     *            , but you need add namespaces manually later.
     * @param locale
     *            Locale to use for returning resources with
     *            {@link #get(String)}.
     * @param missingResourceString
     *            Is showed as i18n'lised value, when resource can't be found.
     */
    public JGLI18N(List<Namespace> namespaces, Locale locale,
            String missingResourceString) {
        if (missingResourceString == null)
            throw new IllegalArgumentException(
                    "\"missingResourceString\" can't be null!");

        if (namespaces != null)
            this.namespaces = namespaces;
        else
            this.namespaces = new ArrayList<Namespace>();

        if (locale != null)
            this.locale = locale;
        else
            this.locale = Locale.getDefault();

        this.missingResourceString = missingResourceString;

        controls = new Hashtable<String, XmlRBC>();

        if (namespaces != null)
            for (Namespace ns : namespaces) {
                if (controls.get(ns.getBundlePath()) == null)
                    controls.put(ns.getBundlePath(), new XmlRBC(ns
                            .getBundlePath()));
            }
    }

    /**
     * Returns i18n'sed value of key in locale specified in {@link #locale}.
     * 
     * @param ns
     *            Namespace, where to seek resource.
     * @param key
     *            Key of resource.
     * @return I18n'sed value.
     * @see #get(String, Locale)
     */
    public String get(Namespace ns, String key) {
        return get(ns, key, locale);
    }

    /**
     * Returns i18n'sed value of key in specified language.
     * 
     * @param ns
     *            Namespace, where to seek resource.
     * @param key
     *            Key to i18n'lise.
     * @param l
     *            Locale to use.
     * @return I18n'sed value.
     */
    public String get(Namespace ns, String key, Locale l) {
        String res = null;
        try {
            XmlRBC control = controls.get(ns.getBundlePath());

            if (control != null)
                res = ResourceBundle.getBundle(ns.getBaseName(), locale,
                        control).getString(key);
            else
                res = missingResourceString;
        }
        catch (MissingResourceException e) {
            res = missingResourceString;
        }
        return res;
    }

    /**
     * Returns default locale used in {@link #get(String)}.
     * 
     * @return Default <code>Locale</code>.
     */
    public Locale getLocale() {
        return locale;
    }

    /**
     * Sets default locale used in {@link #get(String)}.
     * 
     * @param l
     *            <code>Locale</code> to be set default.
     */
    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    /**
     * Adds namespace to handle.
     * 
     * @param ns
     *            Namespace.
     */
    public void addNamespace(Namespace ns) {
        for (Namespace nsExisting : namespaces)
            if (nsExisting.getBundlePath().equals(ns.getBundlePath())
                    && nsExisting.getBaseName().equals(ns.getBaseName()))
                return;

        namespaces.add(ns);

        if (controls.get(ns.getBundlePath()) == null)
            controls.put(ns.getBundlePath(), new XmlRBC(ns.getBundlePath()));
    }

    /**
     * @see #namespaces
     */
    public List<Namespace> getNamespaces() {
        return namespaces;
    }

    /**
     * @see #missingResourceString
     */
    public String getMissingResourceString() {
        return missingResourceString;
    }

}
