package net.sf.jgamelibrary.i18n;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * <code>ResourceBundle</code> that loads it's data from xml properties instead
 * of usual properties.
 * 
 * @author Taras Kostiak
 * 
 */
public class XmlResourceBundle extends ResourceBundle {

    /**
     * Storage of bundle data.
     */
    private Properties pr = null;

    /**
     * Creates new <code>XmlResourceBundle</code> and loads properties from
     * given <code>InputStream</code>.
     * 
     * @throws InvalidPropertiesFormatException
     *             If format of xml file, given in InputStream is invalid.
     * @throws IOException
     *             When an IOException occurs.
     * 
     */
    public XmlResourceBundle(InputStream is)
            throws InvalidPropertiesFormatException, IOException {
        pr = new Properties();
        pr.loadFromXML(is);
    }

    /**
     * Returns an enumeration of the keys.
     * 
     * @see java.util.ResourceBundle#getKeys()
     */
    @SuppressWarnings("unchecked")
    public Enumeration<String> getKeys() {
        Enumeration e = pr.keys();
        return e;
    }

    /**
     * Returns object by key.
     * 
     * @see java.util.ResourceBundle#handleGetObject(java.lang.String)
     */
    protected Object handleGetObject(String key) {
        return pr.getProperty(key);
    }

}
