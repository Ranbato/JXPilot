package net.sf.jgamelibrary.physics.test.xpilot;

import net.sf.jgamelibrary.geom.Util;
import net.sf.jgamelibrary.physics.Collision;
import net.sf.jgamelibrary.physics.CollisionDetector;

public class XPilotCollisionDetector extends CollisionDetector<XPilotEntity> {

	@Override
	public boolean calculateCollision(XPilotEntity e1, XPilotEntity e2,
			double ticks, Collision<XPilotEntity> last,
			Collision<XPilotEntity> result) {
		
		Bullet b;
		XPilotEntity x;
		
		if(e1.isBullet() && !e2.isBullet() && !(e2 instanceof Wall)) {
			b = (Bullet) e1;
			x = e2;
		} else if(e2.isBullet() && !e1.isBullet() && !(e1 instanceof Wall)) {
			b = (Bullet) e2;
			x = e1;
		} else
			return super.calculateCollision(e1, e2, ticks, last, result);
		
		if(Util.intersects(b.getBounds(), x.getBounds())) {
			b.active = false;
			return false;
		} else
			return super.calculateCollision(e1, e2, ticks, last, result);
	}

}
