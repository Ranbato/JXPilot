package net.sf.jgamelibrary.options.model;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlList;
import javax.xml.bind.annotation.XmlRootElement;

import net.sf.jgamelibrary.options.editor.FileOptionEditor;
import net.sf.jgamelibrary.options.editor.OptionEditor;
import net.sf.jgamelibrary.options.option.FileOption;

@XmlRootElement(name = "file")
public class FileOptionModel extends OptionModel<FileOption> {

	@XmlList
	@XmlElement(required = false)
	private String[] extensions;
	
	/**
	 * @return The allowable file name extensions. May be null if there are none.
	 */
	public String[] getExtensions() {return extensions;}
	
	@Override
	public OptionEditor<FileOption> getEditor() {return new FileOptionEditor(this);}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				Arrays.toString(extensions);
	}
}
