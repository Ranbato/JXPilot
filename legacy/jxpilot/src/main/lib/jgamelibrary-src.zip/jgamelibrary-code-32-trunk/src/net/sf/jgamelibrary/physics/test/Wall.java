package net.sf.jgamelibrary.physics.test;

import net.sf.jgamelibrary.geom.*;

public class Wall extends DefaultEntity{
	public boolean isMobile(){return false;}
	
	public Wall(Vector2D v1, Vector2D v2)
	{
		super(new Polygon2D(v1, v2));
	}
}
