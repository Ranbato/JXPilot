package net.sf.jgamelibrary.options.option;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "file")
public class FileOption extends Option {

	@XmlElement(name = "value")
	private String file;

	FileOption() {}
	
	public FileOption(String name, String file) {
		super(name);
		setValue(file);
	}
	
	/**
	 * @return A file name.
	 */
	public String getValue() {return file;}

	public void setValue(String file) {this.file = file;}

}
