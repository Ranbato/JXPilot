package net.sf.jgamelibrary.options.option;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "integer")
public class IntegerOption extends Option {

	@XmlElement
	private int value;
	
	IntegerOption() {}
	
	public IntegerOption(String name, int value) {
		super(name);
		setValue(value);
	}
	
	public Integer getValue() {return value;}

	public void setValue(int value) {this.value = value;}

}
