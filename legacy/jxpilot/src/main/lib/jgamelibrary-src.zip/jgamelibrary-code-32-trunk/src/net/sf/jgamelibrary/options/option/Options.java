package net.sf.jgamelibrary.options.option;

import java.io.File;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "options")
public class Options {

	public static void main(String[] args) throws JAXBException {
		StringOption str = new StringOption("string name", "string value");
		DecimalOption dec = new DecimalOption("decimal name", 3.1415);
		Options options = new Options(str, dec);
		m.marshal(options, new File("OptionTest.xml"));
	}

	private static JAXBContext jc;
	private static Marshaller m;
	private static Unmarshaller u;

	static {
		try {
			jc = JAXBContext.newInstance(Options.class, StringOption.class, FileOption.class,
					EnumOption.class, IntegerOption.class, DecimalOption.class, Option.class);
			m = jc.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			u = jc.createUnmarshaller();
		} catch(JAXBException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Loads options from a file.
	 * @param f The file to load from.
	 * @return The options loaded.
	 * @throws JAXBException Passes on any exceptions thrown by {@link Unmarshaller#unmarshal(File)}.
	 */
	public static Options loadOptions(File f) throws JAXBException {
		return (Options) u.unmarshal(f);
	}

	/**
	 * Saves options to a file.
	 * @param o The options to save.
	 * @param f The file to save to.
	 * @throws JAXBException Passes on any exceptions thrown by {@link Unmarshaller#marshal(File)}.
	 */
	public static void saveOptions(Options o, File f) throws JAXBException {
		m.marshal(o, f);
	}

	@XmlElementRef
	private Option[] options;

	/**
	 * Maps option names to options.
	 */
	private Map<String, Option> optionMap;

	private Options() {}

	public Options(Option... options) {
		this.options = options;
		initMap();
	}

	private void initMap() {
		if(optionMap == null) {
			optionMap = new TreeMap<String, Option>();
			for(Option o : options)
				optionMap.put(o.getName(), o);
		}
	}

	/**
	 * @param name The name of an option.
	 * @return The option associated with the name, or {@code null}
	 * if no such option exists.
	 */
	public Option getOption(String name) {
		initMap();
		return optionMap.get(name);
	}

	/**
	 * @param name The name of an option.
	 * @return The option's value. Equivalent to {@link getOption(name).getValue()},
	 * except that {@code null} is returned if the option does not exist.
	 */
	public Object getValue(String name) {
		Option o = getOption(name);
		if(o == null) return null;
		else return o.getValue();
	}
}
