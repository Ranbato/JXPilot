package net.sf.jgamelibrary.physics;

import net.sf.jgamelibrary.geom.Intersection;
import net.sf.jgamelibrary.geom.Line2D;
import net.sf.jgamelibrary.geom.Segment2D;
import net.sf.jgamelibrary.geom.Vector2D;
import net.sf.jgamelibrary.geom.AbstractPolygon2D;

public class CollisionDetector<T extends AbstractEntity2D<T>> implements AbstractCollisionDetector<T>{
	
	private Line2D path = new Segment2D();
	private Vector2D velocityDif = new Vector2D();
	
	private boolean calculateCollision(Vector2D point, Vector2D pointVelocity, 
			double ticks, Line2D line, Vector2D lineVelocity, Collision<T> result)
	{
		Vector2D.difference(pointVelocity, lineVelocity, velocityDif);
		
		path.getV1().setFrom(point);
		path.getV2().setFrom(point).add(velocityDif, ticks);
		
		if(Intersection.getIntersection(path, line, result.location)!=Intersection.INTERSECTING) return false;
		
		result.ticks = result.location.distance(point)/velocityDif.getMagnitude();
		result.location.add(lineVelocity, result.ticks);
		//result.edge = target;
		result.vertex = point;
		
		return true;
	}
	
	private Collision<T> next = new Collision<T>();
	private Vector2D start = new Vector2D();
	private Line2D target = new Segment2D();
	/**
	 * Calculates the first collision between two entities in a given time frame.
	 * @param e1 The first entity.
	 * @param e2 The second entity.
	 * @param ticks The time frame.
	 * @param result The resulting collision.
	 * @return The result, or null if no collisions occur.
	 */
	public boolean calculateCollision(T e1, T e2,double ticks, Collision<T> result) {
		return calculateCollision(e1,e2,ticks,null, result);
	}
	
	/**
	 * Calculates the first collision between two entities in a given time frame.
	 * @param e1 The first entity.
	 * @param e2 The second entity.
	 * @param ticks The time frame.
	 * @param last The last collision, to prevent duplicate finds.
	 * @param result The resulting collision.
	 * @return Whether a collision was found.
	 */
	public boolean calculateCollision(T e1, T e2,double ticks, Collision<T> last, Collision<T> result)
	{
		
		AbstractPolygon2D p1 = e1.getBounds();
		AbstractPolygon2D p2 = e2.getBounds();
		
		/*
		List<? extends Vector2D> vertices1 = e1.getBounds().getPoints();
		List<? extends Vector2D> vertices2 = e2.getBounds().getPoints();
		List<? extends Line2D> edges1 = e1.getBounds().getEdges();
		List<? extends Line2D> edges2 = e2.getBounds().getEdges();
		 */
		
		boolean found = false;
		
		next.incident=e1;
		next.target=e2;
		for(int v1 =0;v1<p1.numVertices();v1++)
		{
			start = p1.getVertex(v1);
			
			for(int v2 = 0;v2<p2.numVertices();v2++)
			{
				target = p2.getEdge(v2);
				if(last!=null && e1 == last.incident && target == last.edge) continue;
				
				if(calculateCollision(start, e1.getVelocity(), ticks, target, e2.getVelocity(), next))
				{
					if(next.ticks == 0.0) continue;
					
					next.edge = target;
					if(!found)
					{
						found = true;
						result.setFrom(next);
					}
					else if(next.ticks<result.ticks)
					{
						result.setFrom(next);
					}
				}
			}
		}
		
		next.incident=e2;
		next.target=e1;
		for(int v2 =0;v2<p2.numVertices();v2++)
		{
			start = p2.getVertex(v2);
			
			for(int v1 = 0;v1<p1.numVertices();v1++)
			{	
				target = p1.getEdge(v1);
				if(last!=null && e2 == last.incident && target == last.edge) continue;
				
				if(calculateCollision(start, e2.getVelocity(), ticks, target, e1.getVelocity(), next))
				{
					if(next.ticks == 0.0) continue;
					
					next.edge = target;
					if(!found)
					{
						found = true;
						result.setFrom(next);
					}
					else if(next.ticks<result.ticks)
					{
						result.setFrom(next);
					}
				}
			}
		}
		
		return found;
	}

}