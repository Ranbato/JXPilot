package net.sf.jgamelibrary.util;

import java.util.*;

public class SortedList<E> extends ArrayList<E>{
	private Comparator<? super E> comparator;
	
	public SortedList(Comparator<? super E> comparator)
	{
		this.comparator = comparator;
	}
	
	public SortedList(Comparator<? super E> comparator, int size)
	{
		super(size);
		this.comparator = comparator;
	}
	
	/**
	 * Adds an element into the specified position.
	 */
	public boolean add(E element)
	{
		int place = Collections.binarySearch(this, element, comparator);
		
		//element is not in list
		if(place<0)
		{
			place = -place-1;
		}
		super.add(place, element);
		
		return true;
	}
	
	/**
	 * This method does nothing.
	 */
	@Override
	public void add(int index, E element){}
	
	/**
	 * This method does nothing.
	 * @return false
	 */
	@Override
	public boolean addAll(int index, Collection<? extends E> c)
	{return false;}
	
	/**
	 * Adds all the elements of c in sorted order.
	 * @param c The collection of elements.
	 * @return true
	 */
	@Override
	public boolean addAll(Collection<? extends E> c)
	{
		for(E e : c) add(e);
		return true;
	}
	
	public E removeLast()
	{
		return super.remove(super.size()-1);
	}
	
	/**
	 * Uses sorting+binary search to remove elements quickly.
	 * @param element To remove.
	 * @return If element was found and removed.
	 */
	public boolean removeQuick(E element)
	{
		int place = Collections.binarySearch(this, element, comparator);
		
		if(place>=0)
		{
			super.remove(place);
			return true;
		} else return false;
	}
	
	/**
	 * Uses sorting+binary search to find elements quickly.
	 * @param element To search for.
	 * @return If element was found and removed.
	 */
	public boolean containsQuick(E element)
	{
		return Collections.binarySearch(this, element, comparator)>=0;
	}
	
	public int indexOfQuick(E element)
	{
		return Collections.binarySearch(this, element, comparator);
	}
}