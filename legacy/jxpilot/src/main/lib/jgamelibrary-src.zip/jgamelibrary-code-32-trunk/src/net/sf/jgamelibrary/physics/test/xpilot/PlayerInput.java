package net.sf.jgamelibrary.physics.test.xpilot;

public interface PlayerInput {
	public boolean thrusts();
	public boolean turnsRight();
	public boolean turnsLeft();
	public boolean firesShot();
}
