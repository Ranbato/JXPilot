package net.sf.jgamelibrary.options.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import net.sf.jgamelibrary.options.editor.IntegerOptionEditor;
import net.sf.jgamelibrary.options.editor.OptionEditor;
import net.sf.jgamelibrary.options.option.IntegerOption;

@XmlRootElement(name = "integer")
public class IntegerOptionModel extends OptionModel<IntegerOption> {

	@XmlElement(required = false)
	private Integer min, max;
	
	/**
	 * @return The minimum value, inclusive.
	 */
	public Integer getMin() {return min;}
	
	/**
	 * @return The minimum value, exclusive.
	 */
	public Integer getMax() {return max;}

	@Override
	public OptionEditor<IntegerOption> getEditor() {return new IntegerOptionEditor(this);}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				min + "\n" + max;
	}
}
