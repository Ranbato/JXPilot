package net.sf.jgamelibrary.options.option;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "string")
public class StringOption extends Option {

	@XmlElement
	private String value;
	
	StringOption() {}
	
	public StringOption(String name, String value) {
		super(name);
		setValue(value);
	}
	
	@Override
	public String getValue() {return value;}
	public void setValue(String value) {this.value = value;}
}
