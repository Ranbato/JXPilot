package net.sf.jgamelibrary.geom;

import java.awt.Polygon;
import java.awt.geom.Point2D;
import java.util.Collection;

public class TranslatingPolygon2D extends AbstractMovingPolygon2D {
	
	/**
	 * Default UID.
	 */
	private static final long serialVersionUID = 1L;

	private Polygon2D template;
	
	public TranslatingPolygon2D(Collection<? extends Point2D> points) {
		super(points);
		template = new Polygon2D(points);
	}

	public TranslatingPolygon2D(double[] xpoints, double[] ypoints, int npoints) {
		super(xpoints, ypoints, npoints);
		template = new Polygon2D(xpoints, ypoints, npoints);
	}

	public TranslatingPolygon2D(int[] xpoints, int[] ypoints, int npoints) {
		super(xpoints, ypoints, npoints);
		template = new Polygon2D(xpoints, ypoints, npoints);
	}

	public TranslatingPolygon2D(Point2D... points) {
		super(points);
		template = new Polygon2D(points);
	}

	public TranslatingPolygon2D(Polygon other) {
		super(other);
		template = new Polygon2D(other);
	}

	public TranslatingPolygon2D(AbstractPolygon2D other) {
		super(other);
		template = new Polygon2D(other);
	}

	@Override
	protected double getAngle() {return 0.0;}

	@Override
	protected Vector2D getPosition() {return null;}

	@Override
	protected AbstractPolygon2D getTemplate() {
		return template;
	}

}
