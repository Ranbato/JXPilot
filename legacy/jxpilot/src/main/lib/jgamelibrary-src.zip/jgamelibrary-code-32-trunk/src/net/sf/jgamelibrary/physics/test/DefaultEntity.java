package net.sf.jgamelibrary.physics.test;
import net.sf.jgamelibrary.geom.*;
import net.sf.jgamelibrary.physics.*;

public class DefaultEntity extends RotatingEntity2D<DefaultEntity>{
	public boolean interactsWith(DefaultEntity other){return true;}
	public boolean isActive(){return true;}
	public boolean isMobile(){return mobile;}
	
	private boolean mobile;
	
	public DefaultEntity(Polygon2D poly)
	{
		this(poly, true);
	}
	
	public DefaultEntity(Polygon2D poly, boolean mobile)
	{
		super(1, poly);
		this.mobile = mobile;
	}
	
	public DefaultEntity(Polygon2D poly,  double mass)
	{
		super(mass, poly);
		mobile = true;
	}
}