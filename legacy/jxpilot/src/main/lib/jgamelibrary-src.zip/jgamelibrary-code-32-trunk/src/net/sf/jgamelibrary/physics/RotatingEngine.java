package net.sf.jgamelibrary.physics;

import java.util.List;

import net.sf.jgamelibrary.geom.Util;

public class RotatingEngine<T extends AbstractRotatingEntity2D<T>> extends PhysicsEngine<T> {
	public RotatingEngine(CollisionHandler<? super T> handler, AbstractCollisionDetector<T> detector) {
		super(handler, detector);
	}
	
	public RotatingEngine(CollisionHandler<? super T> handler) {
		super(handler);
	}
	
	/**
	 * Creates a new PhysicsEngine with the specified entities and CollisionHandler.
	 * Note that the list should have RandomAccess, as get(index) is used frequently.
	 * @param entities The list of entities.
	 * @param handler The collision handler.
	 */
	public RotatingEngine(List<? extends T> entities, CollisionHandler<? super T> handler) {
		super(entities, handler);
	}
	
	/**
	 * Attempts to rotate an entity by a an angle.
	 * @param entity The entity to be rotated.
	 * @param angle The angle, in radians, by which to rotate.
	 * @return Whether the rotation was successful.
	 */
	protected boolean rotate(T entity, double angle) {
		return setAngle(entity, entity.getAngle()+angle);
	}
	
	/**
	 * Attempts to rotate an entity to the specified angle.
	 * @param entity The entity to be rotated.
	 * @param angle The angle, in radians.
	 * @return Whether the rotation was successful.
	 */
	protected boolean setAngle(T entity, double angle) {
		double previous = entity.getAngle();
		entity.setAngle(angle);
		
		for(int i = 0;i<super.getEntities().size();i++) {
			T e = super.getEntities().get(i);
			if(e != entity && e.isActive() && e.interactsWith(entity) && entity.interactsWith(e)
					&& Util.intersectsEdges(e.getBounds(), entity.getBounds()))
			{
				entity.setAngle(previous);
				return false;
			}
		}
		return true;
	}
}
