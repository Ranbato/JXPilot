package net.sf.jgamelibrary.graphics;

import java.awt.Graphics2D;

/**
 * This Interface describes how to go from regular Cartesian coordinates, with
 * the positive y-axis upwards, to User Space coordinates, with a revrsed y-axis. 
 * @author Vlad Firoiu
 */
public interface Renderable {
	/**
	 * Renders this object with an inverted y-coordinate.
	 * @param g The Graphics2D context onto which to render.
	 */
	public void render(Graphics2D g);
}