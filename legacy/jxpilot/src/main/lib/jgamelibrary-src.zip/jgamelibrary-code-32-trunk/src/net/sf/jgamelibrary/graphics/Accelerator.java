package net.sf.jgamelibrary.graphics;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Class that handles accelerated graphics.
 * @author Vlad Firoiu
 */
public class Accelerator {
	// Acquires the current Graphics Device and Graphics Configuration
	public static final GraphicsEnvironment gfxEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
	public static final GraphicsDevice gfxDevice = gfxEnv.getDefaultScreenDevice();
	public static final GraphicsConfiguration gfxConfig = gfxDevice.getDefaultConfiguration();
	
	public static BufferedImage createCompatibleImage(int width, int height) {
		return gfxConfig.createCompatibleImage(width, height);
	}
}