package net.sf.jgamelibrary.physics;

import net.sf.jgamelibrary.geom.Line2D;
import net.sf.jgamelibrary.geom.Vector2D;

/**
 * Describes a collision between two entities.
 * @author Vlad Firoiu
 *
 * @param <T> The type of entity.
 */
public interface AbstractCollision<T extends AbstractEntity2D<T>> {
	/**
	 * @return The incident entity.
	 */
	public T getIncident();
	
	/**
	 * @return The target entity.
	 */
	public T getTarget();
	
	/**
	 * @return The vertex of the incident entity that hits.
	 */
	public Vector2D getVertex();
	
	/**
	 * @return The edge of the target entity that is hit.
	 */
	public Line2D getEdge();

	/**
	 * @return The actual location of impact.
	 */
	public Vector2D getLocation();
	
	/**
	 * @return The amount of time in the current
	 * frame to impact.
	 */
	public double getTicks();
}
