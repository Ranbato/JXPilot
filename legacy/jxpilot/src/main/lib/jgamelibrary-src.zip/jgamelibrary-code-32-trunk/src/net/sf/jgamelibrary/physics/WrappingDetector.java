package net.sf.jgamelibrary.physics;

import java.awt.geom.Rectangle2D;

import net.sf.jgamelibrary.geom.AbstractPolygon2D;
import net.sf.jgamelibrary.geom.Polygon2D;


public class WrappingDetector<T extends MovingEntity2D<T>> extends CollisionDetector<T> {
	/**
	 * Bounds of world wrapping.
	 */
	private Rectangle2D bounds;
	
	public WrappingDetector(){}
	public WrappingDetector(Rectangle2D bounds) {
		setBounds(bounds);
	}
	
	/**
	 * @return Bounds of world wrapping.
	 */
	public Rectangle2D getBounds() {return bounds;}
	/**
	 * Sets the bounds for wrapping.
	 * @param bounds The new bounds.
	 */
	public void setBounds(Rectangle2D bounds) {this.bounds = bounds;}
	
	
	//private Vector2D 
	private Rectangle2D rect1=new Rectangle2D.Double(), rect2 = new Rectangle2D.Double();
	
	@Override
	public boolean calculateCollision(T e1, T e2, double ticks, Collision<T> last, Collision<T> result) {
		AbstractPolygon2D bounds1 = e1.getBounds();
		AbstractPolygon2D bounds2 = e2.getBounds();
		
		rect1.setFrame(bounds1.getBounds2D());
		rect2.setFrame(bounds2.getBounds2D());
		
		return false;
	}
}
