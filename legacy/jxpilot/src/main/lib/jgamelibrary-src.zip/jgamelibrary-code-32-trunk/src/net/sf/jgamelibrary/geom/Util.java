package net.sf.jgamelibrary.geom;

/**
 * Contains various static utility methods.
 * @author Vlad Firoiu
 */
public final class Util {
	private Util(){};
	
	/**
	 * Determines if two polygons intersect on their interiors.
	 * @param p1 The first polygon.
	 * @param p2 The second polygon.
	 * @return Whether the two polygons' interiors intersect.
	 */
	public static boolean intersects(AbstractPolygon2D p1, AbstractPolygon2D p2) {
		if(p1.getBounds2D().intersects(p2.getBounds2D())) return true;
		
		for(int i = 0 ;i<p1.numVertices();i++)
		{if(p2.contains(p1.getVertex(i))) return true;}
		
		for(int i = 0 ;i<p2.numVertices();i++)
		{if(p1.contains(p2.getVertex(i))) return true;}
		
		return false;
	}
	
	/**
	 * Tests to see whether two polygons' edges intersect.
	 * @param p1 The first Polygon2D
	 * @param p2 The second Polygon2D
	 * @return Whether their edges intersect.
	 */
	public static boolean intersectsEdges(AbstractPolygon2D p1, AbstractPolygon2D p2) {
		for(int i1 = 0;i1 < p1.numVertices();i1++) {
			for(int i2 = 0;i2<p2.numVertices();i2++) {
				if(p1.getEdge(i1).intersectsLine(p2.getEdge(i2))) {return true;}
			}
		}
		return false;
	}
	
	/**
	 * @param x The initial number.
	 * @param modulus The modulus.
	 * @return The correct positive value of {@code x % m}.
	 */
	public static double trueMod(double x, double modulus) {
		double mod = x % modulus;
		return mod < 0 ? mod + modulus : mod;
	}
	
	/**
	 * @param x The initial number.
	 * @param modulus The modulus.
	 * @return The correct positive value of {@code x % m}.
	 */
	public static int trueMod(int x, int modulus) {
		int mod = x % modulus;
		return mod < 0 ? mod + modulus : mod;
	}
}
