package net.sf.jgamelibrary.physics.test;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.util.*;
import java.util.List;

import net.sf.jgamelibrary.geom.Vector2D;
import net.sf.jgamelibrary.graphics.*;

public class DefaultFrame extends BufferedFrame{
	public static void main(String[] args) {
		new DefaultFrame().setVisible(true);
	}
	
	private final int FPS = 200;
	private long start_time, loops=0;
	
	private DefaultEngine engine = new DefaultEngine();
	private Timer timer;
	private Vector2D viewCenter, centerScale, scaleFactor;
	private DefaultRenderer renderer;
	
	public DefaultFrame()
	{
		super(FrameMode.AFS);
		
		viewCenter = new Vector2D(400, 400);
		centerScale = new Vector2D(0.5, 0.5);
		scaleFactor = new Vector2D(0.7, 0.7);
		
		renderer = new DefaultRenderer();
		
		super.addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode()==KeyEvent.VK_ESCAPE)
				{
					DefaultFrame.super.finish();
					timer.cancel();
					double run_time = (System.currentTimeMillis() - start_time)/1000.0;
					double fps = loops / run_time;
					System.out.println("Ran for " + run_time + " seconds." +
										"\nrequested fps = " + FPS +
										"\nactual fps = " + fps);
				}
			}
		});
		
		timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask(){
			private long last_execution;
			private boolean first = true;
			@Override
			public void run() {
				long time = System.currentTimeMillis();
				if(first) {
					first = false;
					start_time = time;
				} else {
					engine.update((double)(time-last_execution)/1000.0);
					DefaultFrame.super.activeRender();
					loops++;
				}
				last_execution = time;
			}
		}, 500, 1000/FPS);
		
		/*
		DisplayMode current = Accelerator.gfxDevice.getDisplayMode();
		try
		{
			Accelerator.gfxDevice.setDisplayMode(new DisplayMode(800,600,32,DisplayMode.REFRESH_RATE_UNKNOWN));
		}
		catch(UnsupportedOperationException e)
		{
			Accelerator.gfxDevice.setDisplayMode(new DisplayMode(800,600,32,DisplayMode.REFRESH_RATE_UNKNOWN));
		}
		*/
	}
	
	@Override
	protected void render(Graphics2D g2d) {
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, super.getWidth(), super.getHeight());
		
		g2d.setColor(Color.WHITE);
		renderer.setDrawTransform(g2d);
		
		List<? extends DefaultEntity> entities = engine.getEntities();
		for(int i = 0;i<entities.size();i++)
			entities.get(i).render(g2d);
	}
	
	private class DefaultRenderer extends AbstractRenderer {

		@Override
		protected Vector2D getCenterScale() {
			return centerScale;
		}

		@Override
		protected int getHeight() {
			return DefaultFrame.super.getHeight();
		}

		@Override
		protected Vector2D getScaleFactor() {
			return scaleFactor;
		}

		@Override
		protected Point2D getViewCenter() {
			return viewCenter;
		}

		@Override
		protected int getWidth() {
			return DefaultFrame.super.getWidth();
		}
		
		@Override
		public void setDrawTransform(Graphics2D g) {
			super.setDrawTransform(g);
		}
	}
}