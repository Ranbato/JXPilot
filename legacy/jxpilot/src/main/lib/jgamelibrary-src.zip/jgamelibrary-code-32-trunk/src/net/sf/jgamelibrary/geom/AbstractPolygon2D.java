package net.sf.jgamelibrary.geom;

import java.awt.Shape;
//import java.util.List;

import net.sf.jgamelibrary.graphics.Renderable;

/**
 * Represents a polygon using {@code Vector2D} objects
 * for vertices.
 * @author Vlad Firoiu
 */
public interface AbstractPolygon2D extends Shape, Renderable {
	public int numVertices();
	public Vector2D getVertex(int index);
	public Line2D getEdge(int index);
	
	//public List<? extends Vector2D> getPoints();
	//public List<? extends Line2D> getEdges();
}
