package net.sf.jgamelibrary.options.editor;

/**
 * Thrown to indicate that an option is not valid.
 * @author Vlad Firoiu
 */
public class InvalidOptionException extends Exception {

	/**
	 * Generated UID.
	 */
	private static final long serialVersionUID = -5421901120267438647L;

	public InvalidOptionException(String message) {
		super(message);
	}

}
