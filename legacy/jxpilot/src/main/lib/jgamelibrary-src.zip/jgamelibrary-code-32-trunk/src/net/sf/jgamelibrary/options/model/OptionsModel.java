package net.sf.jgamelibrary.options.model;

import java.io.File;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "options_model")
public class OptionsModel {
	
	public static void main(String[] args) throws JAXBException {
		OptionsModel models = (OptionsModel) u.unmarshal(new File("OptionModelTest.xml"));
		for(OptionModel<?> m : models.getOptionModels())
			System.out.println(m);
	}
	
	private static JAXBContext jc;
	private static Marshaller m;
	private static Unmarshaller u;
	
	static {
		try {
			jc = JAXBContext.newInstance(OptionsModel.class, StringOptionModel.class, FileOptionModel.class,
					EnumOptionModel.class, IntegerOptionModel.class, DecimalOptionModel.class, OptionModel.class);
			m = jc.createMarshaller();
			u = jc.createUnmarshaller();
		} catch(JAXBException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Loads option models from a file.
	 * @param f The file to load from.
	 * @return The option models loaded.
	 * @throws JAXBException Passes on any exceptions thrown by {@link Unmarshaller#unmarshal(File)}.
	 */
	public static OptionsModel loadOptionsModel(File f) throws JAXBException {
		return (OptionsModel) u.unmarshal(f);
	}
	
	/**
	 * Saves option models to a file.
	 * @param o The option models to save.
	 * @param f The file to save to.
	 * @throws JAXBException Passes on any exceptions thrown by {@link Unmarshaller#marshal(File)}.
	 */
	public static void saveOptionsModel(OptionsModel o, File f) throws JAXBException {
		m.marshal(o, f);
	}
	
	@XmlElementRef
	private OptionModel<?>[] optionModels;
	
	/**
	 * Maps option names to options.
	 */
	private Map<String, OptionModel<?>> optionModelMap;
	
	private OptionsModel() {}
	
	private OptionsModel(OptionModel<?>... optionModels) {
		this.optionModels = optionModels;
		initMap();
	}

	private void initMap() {
		if(optionModelMap == null) {
			optionModelMap = new TreeMap<String, OptionModel<?>>();
			for(OptionModel<?> o : optionModels)
				optionModelMap.put(o.getName(), o);
		}
	}

	/**
	 * @param name The name of an option.
	 * @return The option model associated with the name, or {@code null}
	 * if no such option model exists.
	 */
	public OptionModel<?> getOptionModel(String name) {
		initMap();
		return optionModelMap.get(name);
	}
	
	public OptionModel<?>[] getOptionModels() {return optionModels;}
	
	public Map<String, OptionModel<?>> getOptionModelMap() {
		initMap();
		return optionModelMap;
	}
}
