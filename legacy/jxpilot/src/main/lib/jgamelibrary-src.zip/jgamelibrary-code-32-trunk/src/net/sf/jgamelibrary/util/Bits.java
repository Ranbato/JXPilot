package net.sf.jgamelibrary.util;

import java.util.Arrays;
import java.util.Random;

/**
 * Utility methods on bits.
 * @author Vlad Firoiu
 */
public class Bits {
	/**
	 * Tests {@code Bits} methods.
	 * @param args Not used.
	 */
	public static void main(String[] args) {
		byte[] bytes = new byte[8];
		double random = new Random().nextGaussian();
		System.out.println(random);
		putDouble(random, bytes, 0);
		System.out.println(Arrays.toString(bytes));
		System.out.println(getDouble(bytes, 0));
		System.out.println(getUnsignedInt(Integer.MIN_VALUE));
	}
	
	public static final byte BITS_PER_BYTE = 8;
	
	public static final char makeChar(byte b1, byte b0) {
		return (char)((b1<<8) | (b0 & 0xff));
	}
	
	public static final short makeShort(byte b1, byte b0) {
		return (short)((b1<<8) | (b0 & 0xff));
	}
	
	public static final int makeInt(byte b3, byte b2, byte b1, byte b0) {
		return (int)((((b3 & 0xff) << 24) |
				((b2 & 0xff) << 16) |
				((b1 & 0xff) << 8) |
				((b0 & 0xff) << 0)));
	}
	
	public static final long makeLong(byte b7, byte b6, byte b5, byte b4, byte b3, byte b2, byte b1, byte b0) {
		return ((((long)b7 & 0xff) << 56) |
				(((long)b6 & 0xff) << 48) |
				(((long)b5 & 0xff) << 40) |
				(((long)b4 & 0xff) << 32) |
				(((long)b3 & 0xff) << 24) |
				(((long)b2 & 0xff) << 16) |
				(((long)b1 & 0xff) << 8) |
				(((long)b0 & 0xff) << 0));
	}
	
	public static final float makeFloat(byte b3, byte b2, byte b1, byte b0) {
		return Float.intBitsToFloat(makeInt(b3, b2, b1, b0));
	}
	
	public static final double makeDouble(byte b7, byte b6, byte b5, byte b4, byte b3, byte b2, byte b1, byte b0) {
		return Double.longBitsToDouble(makeLong(b7, b6, b5, b4, b3, b2, b1, b0));
	}
	
	public static final char getChar(byte[] src, int off) {
		return makeChar(src[off], src[off+1]);
	}
	
	public static final short getShort(byte[] src, int off) {
		return makeShort(src[off], src[off+1]);
	}
	
	public static final int getInt(byte[] src, int off) {
		return makeInt(src[off], src[off+1], src[off+2], src[off+3]);
	}
	
	public static final long getLong(byte[] src, int off) {
		return makeLong(src[off], src[off+1], src[off+2], src[off+3], src[off+4], src[off+5], src[off+6], src[off+7]);
	}
	
	public static final float getFloat(byte[] src, int off) {
		return makeFloat(src[off], src[off+1], src[off+2], src[off+3]);
	}
	
	public static final double getDouble(byte[] src, int off) {
		return makeDouble(src[off], src[off+1], src[off+2], src[off+3], src[off+4], src[off+5], src[off+6], src[off+7]);
	}
	
	public static final byte char1(char c){return (byte)(c >> 8);}
	public static final byte char0(char c){return (byte)(c >> 0);}
	
	public static final void putChar(char c, byte[] dest, int off) {
		dest[off] = char1(c);
		dest[off+1] = char0(c);
	}
	
	public static final byte short1(short s){return (byte)(s >> 8);}
	public static final byte short0(short s){return (byte)(s >> 0);}
	
	public static final void putShort(short s, byte[] dest, int off) {
		dest[off] = short1(s);
		dest[off+1] = short0(s);
	}
	
	public static final byte int3(int i) {return (byte)(i >> 24);}
	public static final byte int2(int i) {return (byte)(i >> 16);}
	public static final byte int1(int i) {return (byte)(i >> 8);}
	public static final byte int0(int i) {return (byte)(i >> 0);}
	
	public static final void putInt(int i, byte[] dest, int off) {
		dest[off] = int3(i);
		dest[off+1] = int2(i);
		dest[off+2] = int1(i);
		dest[off+3] = int0(i);
	}

	public static final byte long7(long l) {return (byte)(l >> 56);}
	public static final byte long6(long l) {return (byte)(l >> 48);}
	public static final byte long5(long l) {return (byte)(l >> 40);}
	public static final byte long4(long l) {return (byte)(l >> 32);}
	public static final byte long3(long l) {return (byte)(l >> 24);}
	public static final byte long2(long l) {return (byte)(l >> 16);}
	public static final byte long1(long l) {return (byte)(l >> 8);}
	public static final byte long0(long l) {return (byte)(l >> 0);}
	
	public static final void putLong(long l, byte[] dest, int off) {
		dest[off] = long7(l);
		dest[off+1] = long6(l);
		dest[off+2] = long5(l);
		dest[off+3] = long4(l);
		dest[off+4] = long3(l);
		dest[off+5] = long2(l);
		dest[off+6] = long1(l);
		dest[off+7] = long0(l);
	}
	
	public static final void putFloat(float f, byte[] dest, int off) {
		putInt(Float.floatToRawIntBits(f), dest, off);
	}
	
	public static final void putDouble(double d, byte[] dest, int off) {
		putLong(Double.doubleToRawLongBits(d), dest, off);
	}

	public static final short getUnsignedByte(byte val) {
		return (short)(val & 0xff);
	}
	
	public static final int getUnsignedShort(short val) {
		return (int)val & 0xffff;
	}
	
	public static final long getUnsignedInt(int val) {
		return (long)val & 0xffffffffL;
	}
}
