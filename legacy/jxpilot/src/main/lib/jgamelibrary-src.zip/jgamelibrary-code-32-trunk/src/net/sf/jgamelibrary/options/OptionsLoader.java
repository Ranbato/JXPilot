package net.sf.jgamelibrary.options;

import java.io.File;

import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import net.sf.jgamelibrary.options.option.IntegerOption;
import net.sf.jgamelibrary.options.option.Option;
import net.sf.jgamelibrary.options.option.Options;
import net.sf.jgamelibrary.options.option.StringOption;

public class OptionsLoader {
	public static void main(String[] args) throws JAXBException {
		//Options options = Options.loadOptions(new File("OptionTest.xml"));
	}
}
