package net.sf.jgamelibrary.physics.test.xpilot;

import net.sf.jgamelibrary.geom.Polygon2D;
import net.sf.jgamelibrary.geom.Vector2D;

public class Wall extends XPilotEntity{
	public Wall(Vector2D v1, Vector2D v2)
	{this(new Polygon2D(v1, v2));}
	
	public Wall(Polygon2D bounds) throws NullPointerException
	{
		super(bounds, false);
	}
	
	public boolean isActive(){return true;}
	public boolean interactsWith(XPilotEntity other){return true;}
}