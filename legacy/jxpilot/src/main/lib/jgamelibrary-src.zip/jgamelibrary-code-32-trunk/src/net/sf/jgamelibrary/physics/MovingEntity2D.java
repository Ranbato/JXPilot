package net.sf.jgamelibrary.physics;

import java.awt.Graphics2D;
import java.awt.geom.*;

import net.sf.jgamelibrary.geom.Vector2D;

/**
 * Moving entity class. Handles an entity's position, velocity, acceleration, and change in velocity.
 * @author Vlad Firiou
 */
public abstract class MovingEntity2D<T extends MovingEntity2D<T>> implements AbstractEntity2D<T> {
	private Vector2D
	
	/**
	 * Position in units.
	 */
	position,
	/**
	 * Velocity in units/ticks.
	 */
	velocity,
	/**
	 * Change in velocity, in units/tick
	 */
	deltaVelocity,
	/**
	 * Acceleration in units/ticks^2
	 */
	acceleration;
	
	/**
	 * Mass of this entity.
	 */
	private double mass;
	
	public MovingEntity2D(double mass) throws IllegalArgumentException {
		position = new Vector2D();
		velocity = new Vector2D();
		deltaVelocity = new Vector2D();
		acceleration = new Vector2D();
		setMass(mass);
	}
	
	public Vector2D getPosition() {return position;}
	public Vector2D getVelocity() {return velocity;}
	public Vector2D getAcceleration() {return acceleration;}
	public double getMass(){return mass;}
	
	public MovingEntity2D<T> setPosition(Point2D p) {return this.setPosition(p.getX(), p.getY());}
	
	public MovingEntity2D<T> setPosition(double x, double y) {
		position.setLocation(x, y);
		return this;
	}
	
	public MovingEntity2D<T> setVelocity(Vector2D v) {
		velocity.setFrom(v);
		return this;
	}
	
	public MovingEntity2D<T> setVelocity(double vx, double vy) {
		velocity.setCartesian(vx, vy);
		return this;
	}
	
	public MovingEntity2D<T> setMass(double mass) throws IllegalArgumentException {
		if(mass<0) throw new IllegalArgumentException();
		this.mass = mass;
		return this;
	}
	
	/**
	 * Updates position based on the speed.
	 * @param ticks The time passed.
	 * @return This Entity2D.
	 */
	public void updatePosition(double ticks) {
		position.add(velocity, ticks);
	}
	
	/**
	 * Updates the velocity based on the acceleration.
	 * The acceleration is set to 0.
	 * @param ticks
	 * @return This Entity2D.
	 */
	public void updateVelocity(double ticks) {
		velocity.add(acceleration, ticks);
		acceleration.setToOrigin();
		
		//System.out.println("Velocity = " + velocity);
		velocity.add(deltaVelocity);
		//System.out.println("delta velocity = " + deltaVelocity);
		deltaVelocity.setToOrigin();
		//System.out.println("new velocity = " + velocity);
	}

	/**
	 * Applies a constant force over a period of time.
	 * @param force The force, in mass*acceleration.
	 * @param ticks The amount of time.
	 * @return This {@code MovingEntity2D}
	 */
	public MovingEntity2D<T> applyForce(Vector2D force, double ticks) {
		velocity.add(force, ticks/mass);
		return this;
	}

	/**
	 * Applies a constant acceleration over a period of time.
	 * @param acceleration The acceleration, in distance/time^2.
	 * @param ticks The amount of time.
	 * @return This {@code MovingEntity2D}
	 */
	public MovingEntity2D<T> applyAcceleration(Vector2D acceleration, double ticks) {
		velocity.add(acceleration, ticks);
		return this;
	}
	
	/**
	 * Applies an instantaneous impulse. Occurs when hitting something.
	 * @param direction The velocity of the impulse in distance/time
	 * @param mass The mass of the impulse.
	 * @return This {@code MovingEntity2D}
	 */
	public MovingEntity2D<T> applyImpulse(Vector2D direction, double mass) {
		velocity.add(direction, mass/this.mass);
		return this;
	}
	
	/**
	 * Changes the velocity.
	 * @param v The change in velocity.
	 * @return This Entity2D.
	 */
	public MovingEntity2D<T> addVelocity(Vector2D v) {
		velocity.add(v);
		//deltaVelocity.add(force);
		//System.out.println("new delta velocity = " + deltaVelocity);
		return this;
	}
	
	/**
	 * @param momentum In mass*units/ticks.
	 * @return This {@code MovingEntity2D}
	 */
	public MovingEntity2D<T> applyMomentum(Vector2D momentum) {
		velocity.add(momentum, 1.0/mass);
		return this;
	}
	
	@Override
	public void render(Graphics2D g) {
		getBounds().render(g);
	}
}