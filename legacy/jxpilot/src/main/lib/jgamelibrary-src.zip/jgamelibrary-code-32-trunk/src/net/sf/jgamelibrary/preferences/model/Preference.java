package net.sf.jgamelibrary.preferences.model;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

import net.sf.jgamelibrary.preferences.PreferenceType;

/**
 * This class determines single preference, its type, default value, etc.
 * 
 * @author Taras Kostiak
 * 
 */
// TODO: Fix order of attributes. Next code doesn't do that :(
// @XmlType(propOrder = { "name", "i18nKey", "type", "defaultValue" })
@XmlRootElement(name = "preference")
public class Preference {

    /**
     * Name of preference.<br>
     * Is required.
     */
    protected String name = null;

    /**
     * Default value.<br>
     * Is required.
     */
    protected String defaultValue = null;

    /**
     * Type(for building preferences-releted GUI's).<br>
     * If not specified than default will be used - text field.<br>
     * <br>
     * Types availible:<br>
     * <ul>
     * <li>textField</li>
     * <li>boolean</li>
     * <li>comboBox</li>
     * </ul>
     * 
     * @see PreferenceType
     */
    protected PreferenceType type = null;

    /**
     * Key for i18n.<br>
     * If not specified then <code>preference.NAME</code> will be used(where
     * NAME is {@link #name}).
     */
    protected String i18nKey = null;

    /**
     * Stores additional data for this <code>Preference</code>.
     */
    protected String value = null;

    /**
     * Default constructor.
     */
    public Preference() {
    }

    /**
     * @see #defaultValue
     */
    @XmlAttribute
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * @see #defaultValue
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * @see #name
     */
    @XmlAttribute(required = true)
    public String getName() {
        return name;
    }

    /**
     * @see #name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @see #type
     */
    @XmlAttribute
    public PreferenceType getType() {
        return (type != null) ? (type) : (PreferenceType.TEXT_FIELD);
    }

    /**
     * @see #i18nKey
     */
    @XmlAttribute(name = "i18nKey")
    public String getI18nKey() {
        return (i18nKey != null) ? (i18nKey) : ("preference." + name);
    }

    /**
     * @see #i18nKey
     */
    public void setI18nKey(String key) {
        i18nKey = key;
    }

    /**
     * @see #type
     */
    public void setType(PreferenceType type) {
        this.type = type;
    }

    /**
     * @see #value
     */
    @XmlValue
    public String getValue() {
        return value;
    }

    /**
     * @see #value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
