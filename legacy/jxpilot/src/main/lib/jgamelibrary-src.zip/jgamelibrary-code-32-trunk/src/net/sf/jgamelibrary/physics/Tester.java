package net.sf.jgamelibrary.physics;

import net.sf.jgamelibrary.geom.Vector2D;

public class Tester {
	public static void main(String... args)
	{
		Vector2D v1 = new Vector2D(50,0);
		Vector2D v2 = new Vector2D(v1).rotate(Math.PI/6);
		
		Vector2D tangent = new Vector2D();
		Vector2D normal = new Vector2D();
		
		Vector2D.getComponents(v2, v1, tangent, normal);
		
		System.out.println("tangent: x = " + tangent.getX() + ", y = " + tangent.getY());
		System.out.println("normal: x = " + normal.getX() + ", y = " + normal.getY());
		
		System.out.println("sum: " + Vector2D.sum(tangent, normal, new Vector2D()).getAngle()*180.0/Math.PI);
		
	}
}
