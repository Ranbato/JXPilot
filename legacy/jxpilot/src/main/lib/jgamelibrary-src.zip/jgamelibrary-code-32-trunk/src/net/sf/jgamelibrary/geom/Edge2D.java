package net.sf.jgamelibrary.geom;


/**
 * Similar to a Line2D, but it holds references to points passed in, not to its own copies.
 * This is useful for representing the edges of a polygon.
 * @author Vlad Firoiu
 */
public class Edge2D extends Line2D {
	private Vector2D v1, v2;
	
	public Edge2D(Vector2D v1, Vector2D v2) {
		setEdge(v1,v2);
	}
	
	/**
	 * Resets this edge's pointers.
	 * @param v1 The new first vertex.
	 * @param v2 The new second vertex.
	 * @return This Edge2D.
	 */
	public Edge2D setEdge(Vector2D v1, Vector2D v2) {
		if(v1==null || v2==null) throw new NullPointerException();
		
		this.v1 = v1;
		this.v2 = v2;
		super.updateBounds();
		return this;
	}
	
	public Vector2D getV1(){return v1;}
	public Vector2D getV2(){return v2;}
}