package net.sf.jgamelibrary.geom;

import java.awt.Polygon;
import java.awt.geom.Point2D;
import java.util.Collection;

/**
 * Implementation of {@link AbstractMovingPolygon2D}.
 * @see {@link AbstractMovingPolygon2D}
 * @author Vlad Firoiu
 */
public class MovingPolygon2D extends AbstractMovingPolygon2D {

	/**
	 * Default UID.
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * The template polygon.
	 */
	private Polygon2D template;
	/**
	 * The displacement from the template.
	 */
	private Vector2D position = new Vector2D();
	/**
	 * The angle of rotation.
	 */
	private double angle = 0.0;

	public MovingPolygon2D(Collection<? extends Point2D> points) {
		super(points);
		template = new Polygon2D(points);
	}
	
	public MovingPolygon2D(double[] xpoints, double[] ypoints, int npoints) {
		super(xpoints, ypoints, npoints);
		template = new Polygon2D(xpoints, ypoints, npoints);
	}
	/*
	public MovingPolygon2D(int sides) {
		super(sides);
		template = new Polygon2D(sides);
	}
	 */
	public MovingPolygon2D(int[] xpoints, int[] ypoints, int npoints) {
		super(xpoints, ypoints, npoints);
		template = new Polygon2D(xpoints, ypoints, npoints);
	}
	public MovingPolygon2D(Point2D... points) {
		super(points);
		template = new Polygon2D(points);
	}
	public MovingPolygon2D(Polygon other) {
		super(other);
		template = new Polygon2D(other);
	}
	public MovingPolygon2D(AbstractPolygon2D other) {
		super(other);
		template = new Polygon2D(other);
	}
	
	public void setPosition(Point2D position) {
		setPosition(position.getX(), position.getY());
	}

	public void setPosition(double x, double y) {
		super.translate(x - position.getX(), y - position.getY());
		position.setLocation(x, y);
	}
	
	public MovingPolygon2D translate(Vector2D amount) {
		position.add(amount);
		super.translate(amount);
		return this;
	}
	
	private static final double FULL_ROTATION = 2.0 * Math.PI;
	
	public void setAngle(double angle) {
		if(this.angle != (angle = Util.trueMod(angle, FULL_ROTATION))) {
			this.angle = angle;
			super.updatePolygon();
		}
	}
	@Override
	public MovingPolygon2D rotate(double angle) {
		setAngle(this.angle + angle);
		return this;
	}

	public void setPolygon(double x, double y, double angle) {
		position.setLocation(x, y);
		this.angle = angle;
		super.updatePolygon();
	}
	
	public void setPolygon(Point2D p, double angle) {
		position.setLocation(p);
		this.angle = angle;
		super.updatePolygon();
	}
	
	@Override
	public double getAngle() {return angle;}
	@Override
	public Vector2D getPosition() {return position;}
	@Override
	public AbstractPolygon2D getTemplate() {return template;}
	@Override
	public MovingPolygon2D clone() {
		MovingPolygon2D clone = (MovingPolygon2D) super.clone();
		clone.template = this.template;
		clone.angle = this.angle;
		clone.position = new Vector2D(this.position);
		return clone;
	}
}
