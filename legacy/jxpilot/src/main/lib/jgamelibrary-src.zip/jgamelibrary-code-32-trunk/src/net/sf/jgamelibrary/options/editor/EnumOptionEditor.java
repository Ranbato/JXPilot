package net.sf.jgamelibrary.options.editor;

import java.awt.BorderLayout;

import javax.swing.JComboBox;

import net.sf.jgamelibrary.options.model.EnumOptionModel;
import net.sf.jgamelibrary.options.option.EnumOption;
import net.sf.jgamelibrary.options.option.Option;

@SuppressWarnings("serial")
public class EnumOptionEditor extends OptionEditor<EnumOption> {

	private EnumOptionModel model;
	private EnumOption option;
	
	private JComboBox comboBox;
	
	public EnumOptionEditor(EnumOptionModel model) {
		super(model);
		this.model = model;
		
		comboBox = new JComboBox();
		
		for(String s : model.getValues())
			comboBox.addItem(s);
		
		comboBox.setEditable(false);
		add(comboBox, BorderLayout.CENTER);
	}

	@Override
	public void loadOption(Option option) {
		if(option == null && model.getDefaultValue() != null)
			comboBox.setSelectedItem(model.getDefaultValue());
		else {
			this.option = (EnumOption)option;
			comboBox.setSelectedItem(this.option.getValue());
		}
	}

	@Override
	public EnumOption readOption() {
		if(option == null)
			option = new EnumOption(model.getName(), (String)comboBox.getSelectedItem());
		else option.setValue((String)comboBox.getSelectedItem());
		return option;
	}
}
