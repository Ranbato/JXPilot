package net.sf.jgamelibrary.options.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import net.sf.jgamelibrary.options.editor.DecimalOptionEditor;
import net.sf.jgamelibrary.options.editor.OptionEditor;
import net.sf.jgamelibrary.options.option.DecimalOption;

@XmlRootElement(name = "decimal")
public class DecimalOptionModel extends OptionModel<DecimalOption> {

	@XmlElement(required = false)
	private Double min, max;
	
	public Double getMin() {return min;}
	
	public Double getMax() {return max;}

	@Override
	public OptionEditor<DecimalOption> getEditor() {return new DecimalOptionEditor(this);}
	
	@Override
	public String toString() {
		return super.toString() + "\n" +
				min + "\n" + max;
	}
}
