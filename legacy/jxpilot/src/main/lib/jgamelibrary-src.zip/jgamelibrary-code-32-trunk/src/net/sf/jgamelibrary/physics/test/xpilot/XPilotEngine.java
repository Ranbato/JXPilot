package net.sf.jgamelibrary.physics.test.xpilot;

import java.util.*;

import net.sf.jgamelibrary.geom.*;
import net.sf.jgamelibrary.physics.PhysicsEngine;
import net.sf.jgamelibrary.physics.RotatingEngine;

public class XPilotEngine extends RotatingEngine<XPilotEntity>{
	Ship ship;
	private Wall wall;
	private PlayerInput input;
	
	public XPilotEngine(PlayerInput input) {
		//super(new XPilotCollisionHandler(0.05,0.0), new XPilotCollisionDetector());
		super(new XPilotCollisionHandler(0.05,0.0));
		
		this.input = input;
		
		ArrayList<XPilotEntity> entities = new ArrayList<XPilotEntity>(25);
		
		ship = new Ship();
		ship.setPosition(-200, -200);
		entities.add(ship);
		entities.addAll(ship.bullets);
		
		//System.out.println(ship.getPosition());
		
		wall = new Wall(Polygon2D.regularPolygon(10, 500.0, 0.0));
		//wall.setPosition(200, 200);
		entities.add(wall);
		
		for(int i =0;i<5;i++) {
			XPilotEntity e = new Ship(Polygon2D.regularPolygon(3, 10, i), 1);
			e.getPosition().setCartesian(-50+((i+1)%3)*20*i, (i%3)*20*i);
			e.getVelocity().setCartesian(50*i, -50*i);
			entities.add(e);
		}
		
		super.setEntities(entities);
	}
	
	@Override
	public PhysicsEngine<XPilotEntity> update(double ticks) {
		if(input.thrusts()) ship.thrust(ticks);		
		
		if(input.turnsLeft()) super.rotate(ship, 5.0*ticks);
		else if(input.turnsRight()) super.rotate(ship, -5.0*ticks);
		
		if(input.firesShot()) ship.fireShot();
		
		//if(super.setAngle(ship, -ship.getVelocity().getAngle())) ship.thrust(ticks);
		//super.rotate(wall, ticks);
		
		return super.update(ticks);
	}
}