package net.sf.jgamelibrary.geom;

public class Vector2D extends java.awt.geom.Point2D{
	
	public static Vector2D sum(Vector2D v1, Vector2D v2, Vector2D result)
	{
		result.x = v1.x + v2.x;
		result.y = v1.y + v2.y;
		
		return result;
	}
	
	public static Vector2D difference(Vector2D v1, Vector2D v2, Vector2D result)
	{
		result.x = v1.x - v2.x;
		result.y = v1.y - v2.y;
		
		return result;
	}
	
	public static Vector2D sum(Vector2D result, Vector2D... summands)
	{
		result.setToOrigin();
		for(int i = 0;i<summands.length;i++)
		{
			result.add(summands[i]);
		}		
		return result;
	}
	
	public static Vector2D sum(Vector2D result, Iterable<Vector2D> summands)
	{
		result.setToOrigin();
		for(Vector2D v : summands)
		{
			result.add(v);
		}
		return result;
	}
	
	public static Vector2D unitVector(double angle)
	{
		return new Vector2D().setPolar(1.0, angle);
	}
	
	public static Vector2D unitVector(Vector2D direction)
	{
		return new Vector2D().setFrom(direction).normalize();
	}
	
	/**
	 * @param v1 The first vector.
	 * @param v1Scale The scale factor of the first vector.
	 * @param v2 The second vector.
	 * @param v2Scale The scale factor of the second vector.
	 * @param result Holds the result.
	 * @return (v1Scale)v1 + (v2Scale)v2
	 */
	public static Vector2D sum(Vector2D v1, double v1Scale, Vector2D v2, double v2Scale, Vector2D result)
	{
		result.x = v1Scale*v1.x + v2Scale*v2.x;
		result.y = v1Scale*v1.y + v2Scale*v2.y;
		
		return result;
	}
	
	public static Vector2D difference(Vector2D v1, double v1Scale, Vector2D v2, double v2Scale, Vector2D result)
	{
		result.x = v1Scale*v1.x - v2Scale*v2.x;
		result.y = v1Scale*v1.y - v2Scale*v2.y;
		
		return result;
	}
	
	
	public static double dotProduct(Vector2D v1, Vector2D v2)
	{
		return v1.x*v2.x + v1.y*v2.y;
	}
	
	public static double crossProduct(Vector2D v1, Vector2D v2)
	{
		return v1.x*v2.y - v2.x*v1.y;
	}
	
	/**
	 * @param from The Vector2D being projected.
	 * @param onto The Vector2D onto which "from" is projected.
	 * @return The length of the projection (includes direction).
	 */
	public static double scalarProjection(Vector2D from, Vector2D onto)
	{
		return dotProduct(from, onto)/onto.getMagnitude();
	}
	
	public static Vector2D vectorProjection(Vector2D from, Vector2D onto, Vector2D result)
	{	
		return result.setFrom(onto).multiply(dotProduct(from, onto)/onto.getMagnitudeSquared());
	}
	
	public static Vector2D normalComponent(Vector2D from, Vector2D onto, Vector2D result)
	{
		//return result.setFrom(onto).rotateThreeQuarters().multiply(crossProduct(from, onto)/onto.getMagnitudeSquared());
		return result.setFrom(onto).rotateQuarter().multiply(dotProduct(from, result)/result.getMagnitudeSquared());
	}
	
	/**
	 * @param from The Vector2D being projected.
	 * @param onto The Vector2D onto which "from" is projected.
	 * @param tangent The component of "from" parallel to "onto".
	 * @param normal The component of "from" perpendicular to "onto".
	 */
	public static void getComponents(Vector2D from, Vector2D onto, Vector2D tangent, Vector2D normal)
	{
		vectorProjection(from, onto, tangent);
		difference(from, tangent, normal);
	}
	
	private double x, y;
	
	public Vector2D()
	{
		setToOrigin();
	}
	
	public Vector2D(double x,double y)
	{
		setCartesian(x,y);
	}
	
	public Vector2D(Vector2D other)
	{
		setFrom(other);
	}
	
	public Vector2D setToOrigin()
	{
		setCartesian(0.0,0.0);
		return this;
	}
	
	public Vector2D setFrom(Vector2D other)
	{
		this.x=other.x;
		this.y=other.y;
		return this;
	}
	@Override
	public double getX(){return this.x;}
	@Override
	public double getY(){return this.y;}
	
	public Vector2D setX(double x)
	{
		this.x=x;
		return this;
	}
	public Vector2D setY(double y)
	{
		this.y=y;
		return this;
	}
	
	public Vector2D setCartesian(double x, double y)
	{
		this.x=x;
		this.y=y;
		return this;
	}
	
	@Override
	public void setLocation(double x, double y){setCartesian(x,y);}
	
	/**
	 * @return The angle of this vector from the positive x-axis, in radians.
	 */
	public double getAngle() {
		return Math.atan2(y, x);
	}

	public double getMagnitude()
	{
		return Math.sqrt(getMagnitudeSquared());
	}
	
	public double getMagnitudeSquared()
	{
		return x*x+y*y;
	}
	
	public Vector2D setMagnitude(double magnitude) {
		return this.multiply(magnitude/this.getMagnitude());
	}
	
	public Vector2D setAngle(double theta) {
		return this.setPolar(this.getMagnitude(), theta);
	}
	
	public Vector2D rotate(double angle) {
		return setAngle(this.getAngle()+angle);
	}
	
	/**
	 * Rotates this Vector2D counter-clockwise about the center of rotation.
	 * @param angle The angle by which to rotate, in degrees.
	 * @param center The center of rotation.
	 * @return This Vector2D.
	 */
	public Vector2D rotate(double angle, Vector2D center) {
		return this.subtract(center).rotate(angle).add(center);
	}
	
	/**
	 * Rotates by a quarter turn, counterclockwise.
	 * @return This Vector2D
	 */
	public Vector2D rotateQuarter()
	{
		return this.setCartesian(-y, x);
	}
	
	/**
	 * Rotates by half a turn.
	 * @return This Vector2D
	 */
	public Vector2D rotateHalf()
	{
		return this.setCartesian(-x, -y);
	}
	
	/**
	 * Rotates by a 3/4 of a turn, counterclockwise.
	 * @return This Vector2D
	 */
	public Vector2D rotateThreeQuarters()
	{
		return this.setCartesian(y,-x);
	}
	
	/**
	 * Sets the Vector2D using polar coordinates.
	 * @param r The distance from the origin.
	 * @param theta The angle in radians.
	 * @return This Vector2D.
	 */
	public Vector2D setPolar(double r, double theta)
	{
		this.x = r*Math.cos(theta);
		this.y = r*Math.sin(theta);
		return this;
	}
	
	public Vector2D multiply(double scalar)
	{
		x *= scalar;
		y *= scalar;
		return this;
	}
	
	public Vector2D divide(double scalar)
	{
		x /= scalar;
		y /= scalar;
		return this;
	}
	
	/**
	 * Sets the Vector's magnitude to 1.
	 * @return This Vector2D.
	 */
	public Vector2D normalize()
	{
		return this.setMagnitude(1.0);
	}
	
	public Vector2D add(double dx, double dy)
	{
		x+=dx;
		y+=dy;
		return this;
	}
	
	public Vector2D add(Vector2D other)
	{
		this.x += other.x;
		this.y += other.y;
		return this;
	}
	
	public Vector2D add(Vector2D other, double scale)
	{
		this.x += other.x * scale;
		this.y += other.y * scale;
		
		return this;
	}
	
	public Vector2D subtract(Vector2D other)
	{
		this.x -= other.x;
		this.y -= other.y;
		
		return this;
	}
	
	public Vector2D subtract(Vector2D other, double scale)
	{
		this.x -= other.x*scale;
		this.y -= other.y*scale;
		return this;
	}
	
	public double dotProduct(Vector2D other){return dotProduct(this, other);}
	public double crossProduct(Vector2D other){return crossProduct(this, other);}
	
	public String toString()
	{
		return "<" + x+" , "+y +">";
	}
}