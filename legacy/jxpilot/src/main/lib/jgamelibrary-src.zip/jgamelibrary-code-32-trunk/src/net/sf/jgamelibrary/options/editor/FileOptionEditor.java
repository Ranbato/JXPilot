package net.sf.jgamelibrary.options.editor;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import net.sf.jgamelibrary.options.model.FileOptionModel;
import net.sf.jgamelibrary.options.option.FileOption;
import net.sf.jgamelibrary.options.option.Option;

@SuppressWarnings("serial")
public class FileOptionEditor extends OptionEditor<FileOption> {

	private FileOptionModel model;
	private FileOption option;
	
	private JTextField fileField;
	private JButton chooseButton;
	private JFileChooser fileChooser;
	private FileFilter filter;
	
	public FileOptionEditor(FileOptionModel model) {
		super(model);
		this.model = model;
		
		fileField = new JTextField();
		add(fileField, BorderLayout.CENTER);
		
		chooseButton = new JButton("Choose File");
		chooseButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				fileChooser.showDialog(FileOptionEditor.this, "Select");
				String file = fileChooser.getSelectedFile().getAbsolutePath();
				fileField.setText(file);
				FileOptionEditor.this.validate();
			}
		});
		add(chooseButton, BorderLayout.EAST);
		
		fileChooser = new JFileChooser();
		if(model.getExtensions() != null) {
			filter = new FileNameExtensionFilter(null, model.getExtensions());
			fileChooser.setFileFilter(filter);
		} else filter = null;
	}
	
	@Override
	public void loadOption(Option option) {
		if(option != null) {
			this.option = (FileOption)option;
			fileField.setText(this.option.getValue());
			fileChooser.setSelectedFile(new File(this.option.getValue()));
		}
	}
	
	@Override
	public FileOption readOption() throws InvalidOptionException {
		String fileName = fileField.getText();
		File file = new File(fileName);
		
		if(filter != null && !filter.accept(file)) {
			StringBuilder temp = 
				new StringBuilder("Invalid file extension. File extension must be one of: ");
			String[] exts = model.getExtensions();
			for(int i = 0; i < exts.length; i++)
				temp.append(exts[i]).append(i < exts.length ? ", " : ".");
			throw new InvalidOptionException(temp.toString());
		}
		
		if(!file.exists()) throw new InvalidOptionException("File does not exist.");
		
		if(option == null)
			option = new FileOption(model.getName(), fileName);
		else option.setValue(fileName);
		
		return option;
	}
	
}
