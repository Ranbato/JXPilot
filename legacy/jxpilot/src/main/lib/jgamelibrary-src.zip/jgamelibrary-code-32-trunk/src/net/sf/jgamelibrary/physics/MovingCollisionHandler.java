package net.sf.jgamelibrary.physics;

import net.sf.jgamelibrary.geom.Vector2D;

/**
 * CollisionHandler that handles collisions between moving entities. It can bounce
 * both mobile and immobile entities correctly using their masses and taking into
 * account both normal and tangential friction coefficients.
 * @author Vlad Firoiu
 */
public class MovingCollisionHandler<T extends MovingEntity2D<T>> implements CollisionHandler<T>{
	private double normal_friction, tangent_friction;
	
	public MovingCollisionHandler(){this(0.0);}
	public MovingCollisionHandler(double friction){this(friction, friction);}
	
	public MovingCollisionHandler(double normal_friction, double tangent_friction){
		this.normal_friction=normal_friction;
		this.tangent_friction=tangent_friction;
	}
	
	public void handleCollision(Collision<? extends T> collision)
	{
		if (!collision.incident.isMobile())
		{
			if(!collision.target.isMobile()) return;//cannot collide two immobile entities
			wallCollision(collision, collision.target, collision.incident, normal_friction, tangent_friction);
		}
		else if(!collision.target.isMobile())
		{
			wallCollision(collision, collision.incident, collision.target, normal_friction, tangent_friction);
		}
		else
		{
			bounceCollision(collision);
		}
	}
	
	private Vector2D normalVelocity1 = new Vector2D(), normalVelocity2 = new Vector2D(),
					//tangentVelocity1 = new Vector2D(), tangentVelocity2 = new Vector2D(),
					newVelocity1 = new Vector2D(), newVelocity2 = new Vector2D();
	
	protected void bounceCollision(Collision<? extends T> collision) {
		Vector2D.difference(collision.edge.getV2(), collision.edge.getV1(), collisionFace);
		
		T e1 = collision.incident, e2 = collision.target;
		
		//calculates normal and tangential velocities
		Vector2D.normalComponent(e1.getVelocity(), collisionFace, normalVelocity1);
		Vector2D.normalComponent(e2.getVelocity(), collisionFace, normalVelocity2);
		
		//Vector2D.getComponents(e1.getVelocity(), collisionFace, tangentVelocity1, normalVelocity1);
		//Vector2D.getComponents(e2.getVelocity(), collisionFace, tangentVelocity2, normalVelocity2);
		
		//calculates the new normal velocities
		Vector2D.sum(normalVelocity1, e1.getMass()-e2.getMass(), normalVelocity2, 2.0*e2.getMass(),
				newVelocity1).divide(e1.getMass()+e2.getMass());
		Vector2D.sum(normalVelocity2, e2.getMass()-e1.getMass(), normalVelocity1, 2.0*e1.getMass(),
				newVelocity2).divide(e2.getMass()+e1.getMass());
		
		//applies appropriate instantaneous forces to entities
		e1.addVelocity(newVelocity1.subtract(normalVelocity1));
		e2.addVelocity(newVelocity2.subtract(normalVelocity2));
		
		//e1.ticks = collision.ticks*.99;
		//e2.ticks = collision.ticks*.99;
	}
	
	private Vector2D tangentialMomentum = new Vector2D(), normalMomentum = new Vector2D();
	private Vector2D collisionFace = new Vector2D();
	protected void wallCollision(Collision<? extends T> collision, T mobile, T immobile,
			double normal_friction, double tangent_friction)
	{
		Vector2D.difference(collision.edge.getV2(), collision.edge.getV1(), collisionFace);
		Vector2D.getComponents(mobile.getVelocity(), collisionFace, tangentialMomentum, normalMomentum);
		
		//mobile.ticks = collision.ticks*(0.99);
		
		//System.out.println("normal momentum: "+normalMomentum);
		
		normalMomentum.multiply(normal_friction-2.0);
		mobile.addVelocity(normalMomentum);
		//System.out.println("normal collision force = " + normalMomentum);
		
		//System.out.println("tangent momentum: "+tangentialMomentum);
		
		tangentialMomentum.multiply(-tangent_friction);
		mobile.addVelocity(tangentialMomentum);
	}
}