package net.sf.jgamelibrary.options.model;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlList;
import javax.xml.bind.annotation.XmlRootElement;

import net.sf.jgamelibrary.options.editor.EnumOptionEditor;
import net.sf.jgamelibrary.options.editor.OptionEditor;
import net.sf.jgamelibrary.options.option.EnumOption;

@XmlRootElement(name = "enum")
public class EnumOptionModel extends OptionModel<EnumOption> {
	
	@XmlElement(name = "default", required = false)
	private String defaultValue;
	
	@XmlElement
	@XmlList
	private String[] values;
	
	public String getDefaultValue() {return defaultValue;}
	
	public String[] getValues() {return values;}

	@Override
	public OptionEditor<EnumOption> getEditor() {return new EnumOptionEditor(this);}

	@Override
	public String toString() {
		return super.toString() + "\n" +
				defaultValue + "\n" +
				Arrays.toString(values);
	}
}
