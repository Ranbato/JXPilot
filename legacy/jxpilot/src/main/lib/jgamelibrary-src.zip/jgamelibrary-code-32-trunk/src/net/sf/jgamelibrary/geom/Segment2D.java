package net.sf.jgamelibrary.geom;

/**
 * Direct implementation of {@code Line2D}.
 * @see {@link Line2D}
 * @author Vlad Firoiu
 */
public class Segment2D extends Line2D {
	private Vector2D v1, v2;
	
	public Segment2D() {
		v1 = new Vector2D();
		v2 = new Vector2D();
	}
	
	public Segment2D(double x1, double y1, double x2, double y2) {
		this();
		setLine(x1,y1,x2,y2);
	}
	
	public Segment2D(Vector2D v1, Vector2D v2) {
		this();
		setLine(v1,v2);
	}
	
	public Vector2D getV1(){return v1;}
	public Vector2D getV2(){return v2;}
}