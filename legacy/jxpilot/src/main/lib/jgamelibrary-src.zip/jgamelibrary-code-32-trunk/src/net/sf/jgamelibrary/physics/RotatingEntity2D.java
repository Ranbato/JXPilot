package net.sf.jgamelibrary.physics;

import net.sf.jgamelibrary.geom.AbstractPolygon2D;
import net.sf.jgamelibrary.geom.MovingPolygon2D;
import net.sf.jgamelibrary.geom.Polygon2DAdaptor;

/**
 * Class that implements the bounds and rotation methods of the Entity2D class.
 * @author Vlad Firoiu
 */
public abstract class RotatingEntity2D<T extends RotatingEntity2D<T>>
	extends MovingEntity2D<T> implements AbstractRotatingEntity2D<T>{
	
	private MovingPolygon2D bounds;
	
	/**
	 * Creates a new RotatingEntity2D.
	 * @param mass The mass of the entity.
	 * @param bounds The shape of the entity, centered about the origin.
	 * @throws IllegalArgumentException If the mass is not positive.
	 * @throws NullPointerException If the bounds are null.
	 */
	public RotatingEntity2D(double mass, AbstractPolygon2D bounds) throws IllegalArgumentException, NullPointerException {
		super(mass);
		if(bounds==null) throw new NullPointerException();
		this.bounds = new MovingPolygon2D(bounds);
	}
	
	@Override
	public Polygon2DAdaptor getBounds(){return bounds;}
	@Override
	public double getAngle(){return bounds.getAngle();}
	
	@Override
	public RotatingEntity2D<T> setPosition(double x, double y) {
		super.setPosition(x,y);
		bounds.setPosition(super.getPosition());
		return this;
	}
	
	@Override
	public void updatePosition(double ticks) {
		super.updatePosition(ticks);
		bounds.setPosition(super.getPosition());
	}
	
	@Override
	public void setAngle(double angle) {
		bounds.setAngle(angle);
	}
	
	@Override
	public void rotate(double angle) {
		this.setAngle(this.getAngle()+angle);
	}
}