package net.sf.jgamelibrary.options.editor;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.xml.bind.JAXBException;

import net.sf.jgamelibrary.options.model.OptionModel;
import net.sf.jgamelibrary.options.model.OptionsModel;
import net.sf.jgamelibrary.options.option.Option;
import net.sf.jgamelibrary.options.option.Options;

@SuppressWarnings("serial")
public class OptionsEditor extends JFrame {

	public static void main(String[] args) throws JAXBException {
		OptionsModel model = OptionsModel.loadOptionsModel(new File("OptionModelTest.xml"));
		OptionsEditor editor = new OptionsEditor(model);
		editor.loadOptions(new File("OptionTest.xml"));
		editor.setVisible(true);
	}
	
	private OptionsModel model;
	private OptionModel<?>[] optionModels;
	private OptionEditor<?>[] editors;
	private Options options;
	private File optionsFile;

	private JPanel editorPanel;
	private JComboBox optionBox;
	private int selected;
	private JButton saveButton;

	
	public OptionsEditor(OptionsModel model) {
		this.model = model;
		optionModels = model.getOptionModels();

		editors = new OptionEditor<?>[optionModels.length];
		for(int i = 0; i < optionModels.length; i++) {
			editors[i] = optionModels[i].getEditor();
			editors[i].setVisible(false);
		}

		setLayout(new BorderLayout());

		optionBox = new JComboBox();
		for(int i = 0; i < optionModels.length; i++) {
			optionBox.addItem(optionModels[i].getName());
		}
		optionBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				editors[selected].setVisible(false);
				editors[selected = optionBox.getSelectedIndex()].setVisible(true);
				OptionsEditor.this.validate();
			}
		});
		optionBox.setEditable(true);
		add(optionBox, BorderLayout.NORTH);
		
		
		editorPanel = new JPanel();
		editorPanel.setLayout(new BoxLayout(editorPanel, BoxLayout.Y_AXIS));
		for(int i = 0; i < editors.length; i++)
			editorPanel.add(editors[i]);
		add(new JScrollPane(editorPanel), BorderLayout.CENTER);
		
		
		saveButton = new JButton("Save");
		saveButton.addActionListener(new ActionListener() {
			final JFileChooser fc = new JFileChooser();
			@Override
			public void actionPerformed(ActionEvent ae) {

				Option[] optionArray = new Option[optionModels.length];

				for(int i = 0; i < optionArray.length; i++) {
					try {
						optionArray[i] = editors[i].readOption();
					} catch (InvalidOptionException e) {
						JOptionPane.showMessageDialog(editors[i], "Error in option \"" + optionModels[i].getName() + "\": " + e.getMessage(), "Invalid Option", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}

				options = new Options(optionArray);
				
				if(optionsFile == null) {
					fc.showDialog(OptionsEditor.this, "Save");
					optionsFile = fc.getSelectedFile();
				}
				
				try {
					Options.saveOptions(options, optionsFile);
				} catch (JAXBException e) {
					e.printStackTrace();
				}

				
				//OptionsEditor.this.setVisible(false);
			}
		});
		add(saveButton, BorderLayout.EAST);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	/**
	 * Loads options from a file so they can be edited.
	 * @param f The file to load from.
	 * @throws JAXBException
	 */
	public void loadOptions(File f) throws JAXBException {
		optionsFile = f;
		options = Options.loadOptions(f);

		for(int i = 0; i < optionModels.length; i++) {
			editors[i].loadOption(options.getOption(optionModels[i].getName()));
		}
	}
}
