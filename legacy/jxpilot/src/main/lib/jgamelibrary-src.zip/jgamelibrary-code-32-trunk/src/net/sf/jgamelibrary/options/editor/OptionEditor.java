package net.sf.jgamelibrary.options.editor;

import java.awt.BorderLayout;

import javax.swing.JComponent;
import javax.swing.JLabel;

import net.sf.jgamelibrary.options.model.OptionModel;
import net.sf.jgamelibrary.options.option.Option;

/**
 * Base class for an editor of an option.
 * @author vlad
 *
 * @param <T> The type of option to edit.
 */
@SuppressWarnings("serial")
public abstract class OptionEditor<T extends Option> extends JComponent {
	
	public OptionEditor(OptionModel<T> model) {
		setLayout(new BorderLayout());
		add(new JLabel(model.getName() + ": " + model.getDescription()), BorderLayout.NORTH);
	}
	
	/**
	 * Loads a given option into this editor.
	 * @param option The option to load.
	 */
	public abstract void loadOption(Option option);
	
	/**
	 * Reads an option from this editor.
	 * @return The option read.
	 * @throws InvalidOptionException If there was an error in reading the option.
	 * For example, the option might not conform to this model.
	 */
	public abstract T readOption() throws InvalidOptionException;
}
