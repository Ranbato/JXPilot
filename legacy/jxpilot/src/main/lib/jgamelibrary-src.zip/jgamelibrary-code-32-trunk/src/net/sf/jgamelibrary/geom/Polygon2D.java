package net.sf.jgamelibrary.geom;

import java.awt.Polygon;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Collection;

/**
 * This class is a mixture of old java.awt.Polygon code, modified to use double precision, with some new
 * utility methods.
 * @author Vlad Firoiu
 */
public class Polygon2D extends Polygon2DAdaptor implements java.io.Serializable, Cloneable {

	/**
	 * Creates a regular polygon.
	 * @param sides The number of sides.
	 * @param radius The radius of the circumscribed circle.
	 * @param orientation The offset, in radians, by which the first vertex is from the positive x-axis.
	 * @return The desired regular polygon.
	 */
	public static Polygon2D regularPolygon(int sides, double radius, double orientation) {
		Polygon2D temp = new Polygon2D(sides);
		
		for(int i  = 0;i<sides;i++) {
			temp.vertices.add(i, new Vector2D().setPolar(radius, orientation+2*Math.PI*i/sides));
		}
		temp.initEdges();
		return temp;
	}
	
	private ArrayList<Vector2D> vertices;
	private ArrayList<Edge2D> edges;

	/*
	 * JDK 1.1 serialVersionUID
	 */
	private static final long serialVersionUID = -9L;

	private static final int DEFAULT_SIZE = 4;
	
	/**
	 * Creates an empty polygon.
	 */
	public Polygon2D() {
		this(DEFAULT_SIZE);
	}
	
	/**
	 * Creates an empty polygon.
	 */
	public Polygon2D(int sides) {
		vertices = new ArrayList<Vector2D>(sides);
		edges = new ArrayList<Edge2D>(sides);
	}
	
	
	/**
	 * Constructs and initializes a <code>Polygon</code> from the specified
	 * parameters.
	 * @param xpoints an array of <i>x</i> coordinates
	 * @param ypoints an array of <i>y</i> coordinates
	 * @param npoints the total number of points in the
	 * <code>Polygon</code>
	 * @exception NegativeArraySizeException if the value of
	 * <code>npoints</code> is negative.
	 * @exception IndexOutOfBoundsException if <code>npoints</code> is
	 * greater than the length of <code>xpoints</code>
	 * or the length of <code>ypoints</code>.
	 * @exception NullPointerException if <code>xpoints</code> or
	 * <code>ypoints</code> is <code>null</code>.
	 */
	public Polygon2D(double xpoints[], double ypoints[], int npoints) {
		// Fix 9: should throw IndexOutofBoundsException instead
		// of OutofMemoryException if npoints is huge and > {x,y}points.length
		vertices = new ArrayList<Vector2D>(npoints);

		for(int i =0;i<npoints;i++) {
			vertices.add(new Vector2D(xpoints[i], ypoints[i]));
		}
		initEdges();
		updateBounds();
	}
	/**
	 * Constructs and initializes a <code>Polygon</code> from the specified
	 * parameters.
	 * @param xpoints an array of <i>x</i> coordinates
	 * @param ypoints an array of <i>y</i> coordinates
	 * @param npoints the total number of points in the
	 * <code>Polygon</code>
	 * @exception NegativeArraySizeException if the value of
	 * <code>npoints</code> is negative.
	 * @exception IndexOutOfBoundsException if <code>npoints</code> is
	 * greater than the length of <code>xpoints</code>
	 * or the length of <code>ypoints</code>.
	 * @exception NullPointerException if <code>xpoints</code> or
	 * <code>ypoints</code> is <code>null</code>.
	 */
	public Polygon2D(int xpoints[], int ypoints[], int npoints) {
		// Fix 9: should throw IndexOutofBoundsException instead
		// of OutofMemoryException if npoints is huge and > {x,y}points.length
		vertices = new ArrayList<Vector2D>(npoints);

		for(int i =0;i<npoints;i++) {
			vertices.add(new Vector2D(xpoints[i], ypoints[i]));
		}
		initEdges();
		updateBounds();
	}
	
	public Polygon2D(Point2D... points) {
		this.vertices = new ArrayList<Vector2D>(points.length);
		for(int i =0;i<points.length;i++) {
			Vector2D v = new Vector2D();
			v.setLocation(points[i]);
			this.vertices.add(v);
		}
		initEdges();
		updateBounds();
	}

	public Polygon2D(Collection<? extends Point2D> points) {
		this.vertices = new ArrayList<Vector2D>(points.size());
		for(Point2D p : points) {
			Vector2D v = new Vector2D();
			v.setLocation(p);
			this.vertices.add(v);
		}
		initEdges();
		updateBounds();
	}
	
	public Polygon2D(AbstractPolygon2D other) {
		this.vertices = new ArrayList<Vector2D>(other.numVertices());
		for(int i = 0;i < other.numVertices();i++) {
			vertices.add(new Vector2D(other.getVertex(i)));
		}
		initEdges();
		updateBounds();
	}
	
	public Polygon2D(Polygon other) {
		this(other.xpoints, other.ypoints, other.npoints);
	}
	
	/**
	 * Initializes and sets the edges.
	 */
	private void initEdges() {
		edges = new ArrayList<Edge2D>(vertices.size());
		for(int i = 0;i<vertices.size();i++)
		{
			edges.add(new Edge2D(vertices.get(i), vertices.get((i+1)%vertices.size())));
		}
	}
	
	@Override
	public Polygon2D clone() {
		return new Polygon2D(this);
	}
	
	/**
	 * Resets this <code>Polygon</code> object to an empty polygon.
	 * The coordinate arrays and the data in them are left untouched
	 * but the number of points is reset to zero to mark the old
	 * vertex data as invalid and to start accumulating new vertex
	 * data at the beginning.
	 * All internally-cached data relating to the old vertices
	 * are discarded.
	 * Note that since the coordinate arrays from before the reset
	 * are reused, creating a new empty <code>Polygon</code> might
	 * be more memory efficient than resetting the current one if
	 * the number of vertices in the new polygon data is significantly
	 * smaller than the number of vertices in the data from before the
	 * reset.
	 * @see java.awt.Polygon#invalidate
	 * @since 1.4
	 */
	public void reset() {
		vertices.clear();
		edges.clear();
		bounds = null;
	}

	/**
	 * Invalidates or flushes any internally-cached data that depends
	 * on the vertex coordinates of this <code>Polygon</code>.
	 * This method should be called after any direct manipulation
	 * of the coordinates in the <code>xpoints</code> or
	 * <code>ypoints</code> arrays to avoid inconsistent results
	 * from methods such as <code>getBounds</code> or <code>contains</code>
	 * that might cache data from earlier computations relating to
	 * the vertex coordinates.
	 * @see java.awt.Polygon#getBounds
	 * @since 1.4
	 */
	public void invalidate() {
		bounds = null;
	}

	public int numVertices(){return vertices.size();}
	public Vector2D getVertex(int index) {return vertices.get(index);}
	public Line2D getEdge(int index) {return edges.get(index);}
	
	public void setVertex(int index, Vector2D v) {vertices.get(index).setFrom(v);}
	public void setEdge(int index, Line2D l) {edges.get(index).setLine(l);}
	
	public java.util.List<Vector2D> getPoints(){return vertices;}
	/**
	 * Note that edge number i points to vertices i and (i+1)%(npoints)
	 * @return The edges.
	 */
	public java.util.List<Edge2D> getEdges(){return edges;}
	/**
	 * Translates the vertices of the <code>Polygon</code> by
	 * <code>deltaX</code> along the x axis and by
	 * <code>deltaY</code> along the y axis.
	 * @param deltaX the amount to translate along the <i>x</i> axis
	 * @param deltaY the amount to translate along the <i>y</i> axis
	 * @since JDK1.1
	 */
	public Polygon2D translate(double deltaX, double deltaY) {
		for (int i = 0; i < vertices.size(); i++) {
			vertices.get(i).add(deltaX, deltaY);
		}
		if (bounds != null) {
			bounds.setFrame(bounds.getMinX()+deltaX, bounds.getMinY()+deltaY,
					bounds.getWidth(), bounds.getHeight());
		}
		return this;
	}

	public Polygon2D translate(Vector2D amount) {
		return translate(amount.getX(), amount.getY());
	}
	
	/**
	 * Rotates counterclockwise about the origin by the specified angle.
	 * @param angle By which to rotate, in radians.
	 * @return This Polygon2D.
	 */
	public Polygon2D rotate(double angle) {
		for(int i =0;i<vertices.size();i++) {
			vertices.get(i).rotate(angle);
		}
		super.updateBounds();
		return this;
	}
	
	public Polygon2D rotate(double angle, Vector2D center) {
		for(int i =0;i<vertices.size();i++) {
			vertices.get(i).rotate(angle, center);
		}
		super.updateBounds();
		return this;
	}
	
	public Polygon2D transform(AffineTransform tx) {
		for(int i=0;i<vertices.size();i++) {
			Point2D p = vertices.get(i);
			tx.transform(p,p);
		}
		super.updateBounds();
		return this;
	}
	
	/**
	 * Appends the specified coordinates to this <code>Polygon</code>.
	 * <p>
	 * If an operation that calculates the bounding box of this
	 * <code>Polygon</code> has already been performed, such as
	 * <code>getBounds</code> or <code>contains</code>, then this
	 * method updates the bounding box.
	 * @param x the specified x coordinate
	 * @param y the specified y coordinate
	 * @see java.awt.Polygon#getBounds
	 * @see java.awt.Polygon#contains
	 */
	public Polygon2D addVertex(double x, double y) {
		vertices.add(new Vector2D(x,y));
		if(edges.size()>0) edges.get(edges.size()-1).setEdge(vertices.get(edges.size()-1), vertices.get(edges.size()));
		edges.add(new Edge2D(vertices.get(vertices.size()-1), vertices.get(0)));
		if (bounds != null) {
			updateBounds(x, y);
		}
		return this;
	}

	public Polygon2D addVertex(Point2D p) {
		return addVertex(p.getX(), p.getY());
	}
	
	public static boolean intersects(Polygon2D p1, Polygon2D p2) {
		for(int i = 0 ;i<p1.numVertices();i++)
		{if(p2.contains(p1.vertices.get(i))) return true;}
		
		for(int i = 0 ;i<p2.numVertices();i++)
		{if(p1.contains(p2.vertices.get(i))) return true;}
		
		return false;
	}
	
	/**
	 * Tests to see whether two polygons' edges intersect.
	 * @param p1 The first Polygon2D
	 * @param p2 The second Polygon2D
	 * @return Whether their edges intersect.
	 */
	public static boolean intersectsEdges(Polygon2D p1, Polygon2D p2)
	{
		for(int i1 = 0;i1 < p1.numVertices();i1++)
		{
			Edge2D e1 = p1.edges.get(i1);
			for(int i2 = 0;i2<p2.numVertices();i2++)
			{
				Edge2D e2 = p2.edges.get(i2);
				if(e1.intersectsLine(e2)) {
					return true;
				}
			}
		}
		return false;
	}
}